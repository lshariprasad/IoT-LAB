(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const urlInput = $('deviceUrl');
  const connectForm = $('connectForm');
  const connectButton = $('connectButton');
  const hint = $('connectionHint');
  const pill = $('connectionPill');
  const connectionText = $('connectionText');
  const distanceValue = $('distanceValue');
  const distanceUnit = $('distanceUnit');
  const sensorState = $('sensorState');
  const robotState = $('robotState');
  const robotSubstate = $('robotSubstate');
  const obstacleAlert = $('obstacleAlert');
  const sensorAlert = $('sensorAlert');
  const lastUpdate = $('lastUpdate');
  const controls = Array.from(document.querySelectorAll('[data-direction]'));

  let deviceBase = '';
  let connected = false;
  let activeDirection = 'S';
  let activeButton = null;
  let heartbeatTimer = null;
  let pollTimer = null;
  let lastValidStatusAt = 0;
  let requestBusy = false;

  const labels = {
    F: ['FORWARD', 'Moving forward'],
    B: ['REVERSE', 'Reversing'],
    L: ['LEFT', 'Turning left'],
    R: ['RIGHT', 'Turning right'],
    S: ['STOPPED', 'Motors idle']
  };

  function normalizeBase(value) {
    const trimmed = String(value || '').trim();
    if (!trimmed) throw new Error('Enter the ESP32 IP address first.');
    const withScheme = /^https?:\/\//i.test(trimmed) ? trimmed : `http://${trimmed}`;
    const parsed = new URL(withScheme);
    if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Use an http:// or https:// address.');
    return parsed.origin;
  }

  function setConnection(isOnline, message) {
    connected = isOnline;
    pill.classList.toggle('pill-online', isOnline);
    pill.classList.toggle('pill-offline', !isOnline);
    connectionText.textContent = isOnline ? 'Connected' : 'Not connected';
    if (message) hint.textContent = message;
  }

  async function api(path, timeoutMs = 2200) {
    if (!deviceBase) throw new Error('No ESP32 address has been set.');
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(`${deviceBase}${path}`, {
        method: 'GET',
        cache: 'no-store',
        mode: 'cors',
        signal: controller.signal
      });
      if (!response.ok) throw new Error(`ESP32 replied with HTTP ${response.status}.`);
      return response;
    } finally {
      clearTimeout(timeout);
    }
  }

  async function sendCommand(direction) {
    if (!deviceBase) return;
    try {
      const response = await api(`/cmd?d=${encodeURIComponent(direction)}`);
      const result = await response.json();
      if (direction !== 'S' && result.blocked) {
        hint.textContent = 'Movement blocked by the obstacle or sensor safety check.';
      }
    } catch (error) {
      setConnection(false, explainNetworkError(error));
      stopHeartbeat();
    }
  }

  function explainNetworkError(error) {
    if (error && error.name === 'AbortError') return 'ESP32 did not respond in time. Check the IP address and Wi-Fi.';
    return 'Cannot reach ESP32. Check the address, same Wi-Fi network, CORS setup, and browser security restrictions.';
  }

  function startHeartbeat() {
    stopHeartbeat();
    heartbeatTimer = setInterval(async () => {
      try {
        await api('/heartbeat', 1600);
      } catch (error) {
        setConnection(false, explainNetworkError(error));
        releaseMovement(false);
      }
    }, 250);
  }

  function stopHeartbeat() {
    if (heartbeatTimer !== null) clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }

  function activateButton(button) {
    if (activeButton) activeButton.classList.remove('is-active');
    activeButton = button;
    if (activeButton) activeButton.classList.add('is-active');
  }

  function beginMovement(direction, button) {
    if (direction === 'S') {
      releaseMovement(true);
      return;
    }
    if (!connected || !deviceBase) {
      hint.textContent = 'Connect to the ESP32 before moving the robot.';
      return;
    }
    // Prevent a second pointer from changing the active control.
    if (activeDirection !== 'S') return;
    activeDirection = direction;
    activateButton(button);
    sendCommand(direction);
    startHeartbeat();
  }

  function releaseMovement(sendStop = true) {
    const wasMoving = activeDirection !== 'S';
    activeDirection = 'S';
    stopHeartbeat();
    if (activeButton) activeButton.classList.remove('is-active');
    activeButton = null;
    if (sendStop && wasMoving && deviceBase) sendCommand('S');
  }

  async function refreshStatus() {
    if (!deviceBase || requestBusy) return;
    requestBusy = true;
    try {
      const response = await api('/status', 2200);
      const status = await response.json();
      lastValidStatusAt = Date.now();
      setConnection(true, `Connected to ${deviceBase}`);

      const distance = Number(status.distanceCm);
      const sensorOk = status.sensorOk === true || (Number.isFinite(distance) && distance >= 0);
      const obstacle = status.obstacle === true || (Number.isFinite(distance) && distance >= 0 && distance <= 5);
      const command = labels[status.command] ? status.command : 'S';

      distanceUnit.textContent = 'cm';
      if (Number.isFinite(distance) && distance >= 0) {
        distanceValue.textContent = distance.toFixed(1);
        sensorState.textContent = obstacle ? 'Obstacle inside 5 cm zone' : 'Sensor reading available';
      } else {
        distanceValue.textContent = '—';
        sensorState.textContent = 'No valid echo';
      }

      robotState.textContent = labels[command][0];
      robotState.style.color = command === 'S' ? 'var(--green)' : '#9bc6ff';
      robotSubstate.textContent = labels[command][1];
      obstacleAlert.hidden = !obstacle;
      sensorAlert.hidden = sensorOk || obstacle;
      lastUpdate.textContent = `Updated ${new Date().toLocaleTimeString()}`;
      if (obstacle) hint.textContent = 'Obstacle detected at 5 cm or closer. Reverse remains available.';
      else if (!sensorOk) hint.textContent = 'Sensor reading unavailable. Check the HC-SR04 wiring and ECHO voltage divider.';
    } catch (error) {
      setConnection(false, explainNetworkError(error));
      if (lastValidStatusAt && Date.now() - lastValidStatusAt > 3000) {
        distanceValue.textContent = '—';
        sensorState.textContent = 'Connection lost';
      }
    } finally {
      requestBusy = false;
    }
  }

  connectForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    releaseMovement(true);
    let normalized;
    try {
      normalized = normalizeBase(urlInput.value);
    } catch (error) {
      setConnection(false, error.message || 'Invalid ESP32 address.');
      return;
    }
    deviceBase = normalized;
    urlInput.value = normalized;
    try { localStorage.setItem('esp32RobotDeviceUrl', normalized); } catch (_) { /* storage is optional */ }
    connectButton.disabled = true;
    connectButton.textContent = 'Connecting…';
    setConnection(false, `Trying ${deviceBase}…`);
    try {
      const response = await api('/status', 3500);
      const status = await response.json();
      if (!status || !Object.prototype.hasOwnProperty.call(status, 'distanceCm')) {
        throw new Error('The device answered, but the robot API was not found. Upload the included firmware.');
      }
      setConnection(true, `Connected to ${deviceBase}`);
      await refreshStatus();
    } catch (error) {
      setConnection(false, error.message || explainNetworkError(error));
    } finally {
      connectButton.disabled = false;
      connectButton.textContent = 'Connect';
    }
  });

  controls.forEach((button) => {
    const direction = button.dataset.direction;
    button.addEventListener('pointerdown', (event) => {
      event.preventDefault();
      if (typeof button.setPointerCapture === 'function') {
        try { button.setPointerCapture(event.pointerId); } catch (_) { /* optional */ }
      }
      beginMovement(direction, button);
    });
    button.addEventListener('click', (event) => {
      // Stop always sends a command, even if the local UI lost movement state.
      if (direction === 'S') {
        event.preventDefault();
        activeDirection = 'S';
        stopHeartbeat();
        if (activeButton) activeButton.classList.remove('is-active');
        activeButton = null;
        sendCommand('S');
      }
    });
  });

  window.addEventListener('pointerup', () => releaseMovement(true));
  window.addEventListener('pointercancel', () => releaseMovement(true));
  window.addEventListener('blur', () => releaseMovement(true));
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) releaseMovement(true);
  });
  window.addEventListener('keydown', (event) => {
    if (['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) return;
    const map = { ArrowUp: 'F', ArrowDown: 'B', ArrowLeft: 'L', ArrowRight: 'R', ' ': 'S' };
    const direction = map[event.key];
    if (!direction || event.repeat) return;
    event.preventDefault();
    const button = controls.find((item) => item.dataset.direction === direction);
    if (button) beginMovement(direction, button);
  });
  window.addEventListener('keyup', (event) => {
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(event.key)) releaseMovement(true);
  });

  try {
    const saved = localStorage.getItem('esp32RobotDeviceUrl');
    if (saved) urlInput.value = saved;
  } catch (_) { /* storage is optional */ }
  pollTimer = setInterval(refreshStatus, 600);
  window.addEventListener('beforeunload', () => {
    stopHeartbeat();
    if (pollTimer !== null) clearInterval(pollTimer);
  });
})();
