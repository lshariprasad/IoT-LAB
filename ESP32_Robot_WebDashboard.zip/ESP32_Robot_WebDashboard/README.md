# ESP32 Wi-Fi Robot Web Dashboard

A responsive, dependency-free web dashboard for the ESP32 + L298N motor driver + HC-SR04 ultrasonic sensor robot. It includes a live distance display, connection status, press-and-hold movement controls, 5 cm obstacle warning, and a stop-on-release/heartbeat pattern.

## Files

- `index.html` — dashboard page
- `style.css` — responsive styling
- `app.js` — connection, status polling, and drive controls
- `firmware/ESP32_Robot_Dashboard_API.ino` — ESP32 firmware for the separate dashboard

## 1. Flash the included ESP32 firmware

1. In Arduino IDE, open `firmware/ESP32_Robot_Dashboard_API.ino`.
2. Check the Wi-Fi credentials near the top. They are currently set to `SSE-EEE` and `123456789`.
3. Verify the pin mapping matches the actual wiring:
   - L298N IN1 = GPIO 26
   - L298N IN2 = GPIO 27
   - L298N IN3 = GPIO 25
   - L298N IN4 = GPIO 33
   - HC-SR04 TRIG = GPIO 19
   - HC-SR04 ECHO = GPIO 18 through a voltage divider
4. Select **ESP32 Dev Module**, choose the correct COM port, and upload.
5. Open Serial Monitor at **115200 baud**. Copy the IP address printed by the ESP32.

### Power and safety wiring

- Connect ESP32 GND, L298N GND, and motor-supply negative together.
- Power motors from an appropriate external motor supply, not from an ESP32 GPIO pin.
- For the common L298N boards, install ENA and ENB jumpers for this full-speed code.
- Standard HC-SR04 ECHO can output 5 V. Use a resistor divider to reduce ECHO to approximately 3.3 V before connecting it to GPIO 18.
- Test with wheels lifted before placing the robot on the floor.

## 2. Open the dashboard

### Quick local test

Open `index.html` in a desktop browser, or serve this directory from a **local HTTP web server**. Enter the ESP32 IP address, such as `http://192.168.1.105`, and tap **Connect**. Your actual IP may be different.

The browser may require CORS permission for the page to communicate with the ESP32. The included firmware adds CORS response headers to the API.

### Upload through FileZilla

FileZilla is an FTP/SFTP client, not a web host. Use it to upload `index.html`, `style.css`, and `app.js` into the website's public web directory (often named `public_html`, `htdocs`, or `www`). Keep all three files in the same directory.

The browser device must be connected to the **same Wi-Fi/LAN** as the ESP32 and must be able to reach its private IP address. A public website cannot reach an ESP32 on a different private network.

**Browser security limitation:** If the uploaded website is served over HTTPS but the ESP32 API is plain HTTP (`http://192.168...`), browsers may block the request as mixed content or due to local-network access restrictions. CORS headers cannot override those browser security rules. For a reliable first demo, use the dashboard from a local file/local HTTP server or the web page served directly by the ESP32 on its IP. An external HTTPS website generally needs a properly secured bridge/proxy to control a device on your LAN.

## 3. Dashboard controls

- Press and hold **Forward**, **Reverse**, **Left**, or **Right** to drive.
- Release the button to issue Stop.
- Click **Stop** at any time to stop the motors.
- The dashboard polls distance and status every 600 ms.
- If browser heartbeats stop, firmware stops active motors after 800 ms.
- At 5 cm or closer, forward and turning commands are blocked; reverse is permitted to back away.
- If the ultrasonic sensor returns no valid echo, forward and turning commands are blocked as a safety precaution.

## 4. Troubleshooting

- **Dashboard says it cannot connect:** Check the IP address, same-network connection, and that the included firmware is running. If using an uploaded website, check the browser's HTTPS/mixed-content and local-network restrictions.
- **Motor does not turn:** Verify external motor power, common ground, motor output terminals, IN1–IN4 mapping, and ENA/ENB jumpers. The ESP32 USB supply alone is normally not sufficient for motors.
- **No valid echo:** Check HC-SR04 VCC/GND/TRIG/ECHO and the ECHO divider. Do not put 5 V directly into an ESP32 GPIO.
- **Fallback AP:** If router Wi-Fi fails for 15 seconds, firmware starts `ESP32-Robot` with password `robot123`. Connect to this network and use the dashboard IP `http://192.168.4.1`; since there may be no internet on this AP, keep a local copy of the dashboard available.

## Network and security note

This demonstration API is intended for a trusted local test network. It does not provide user authentication or encryption. Do not forward the ESP32's port 80 to the public internet or expose the robot control endpoint on an untrusted network.
