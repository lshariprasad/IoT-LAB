#include <WiFi.h>
#include <WebServer.h>

// Wi-Fi credentials
const char* WIFI_SSID = "SSE-EEE";
const char* WIFI_PASSWORD = "123456789";

// Fallback Access Point if router connection fails
const char* AP_SSID = "ESP32-Robot";
const char* AP_PASSWORD = "robot123";

// L298N pins (ENA and ENB jumpers installed for full speed)
const int IN1_PIN = 26;
const int IN2_PIN = 27;
const int IN3_PIN = 25;
const int IN4_PIN = 33;

// HC-SR04 pins. ECHO must pass through a voltage divider.
const int TRIG_PIN = 19;
const int ECHO_PIN = 18;

const float STOP_DISTANCE_CM = 5.0f;
const unsigned long SENSOR_INTERVAL_MS = 65;
const unsigned long COMMAND_TIMEOUT_MS = 800;

WebServer server(80);
float distanceCm = -1.0f;
char motorCommand = 'S';
unsigned long lastSensorRead = 0;
unsigned long lastCommandTime = 0;
bool networkStartedAsAP = false;

void addCorsHeaders() {
  // For a hobby demo. See README security note before exposing this API.
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
  server.sendHeader("Access-Control-Allow-Private-Network", "true");
  server.sendHeader("Access-Control-Max-Age", "600");
}

void sendJson(int statusCode, const String& body) {
  addCorsHeaders();
  server.sendHeader("Cache-Control", "no-store");
  server.send(statusCode, "application/json", body);
}

void stopMotors() {
  digitalWrite(IN1_PIN, LOW);
  digitalWrite(IN2_PIN, LOW);
  digitalWrite(IN3_PIN, LOW);
  digitalWrite(IN4_PIN, LOW);
}

void driveMotors(char direction) {
  switch (direction) {
    case 'F':
      digitalWrite(IN1_PIN, HIGH); digitalWrite(IN2_PIN, LOW);
      digitalWrite(IN3_PIN, HIGH); digitalWrite(IN4_PIN, LOW);
      break;
    case 'B':
      digitalWrite(IN1_PIN, LOW); digitalWrite(IN2_PIN, HIGH);
      digitalWrite(IN3_PIN, LOW); digitalWrite(IN4_PIN, HIGH);
      break;
    case 'L':
      digitalWrite(IN1_PIN, LOW); digitalWrite(IN2_PIN, HIGH);
      digitalWrite(IN3_PIN, HIGH); digitalWrite(IN4_PIN, LOW);
      break;
    case 'R':
      digitalWrite(IN1_PIN, HIGH); digitalWrite(IN2_PIN, LOW);
      digitalWrite(IN3_PIN, LOW); digitalWrite(IN4_PIN, HIGH);
      break;
    default:
      stopMotors();
      break;
  }
}

bool obstacleClose() {
  return distanceCm >= 0.0f && distanceCm <= STOP_DISTANCE_CM;
}

bool sensorValid() {
  return distanceCm >= 0.0f;
}

float measureDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(3);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  unsigned long duration = pulseIn(ECHO_PIN, HIGH, 25000UL);
  if (duration == 0) return -1.0f;
  return (duration * 0.0343f) / 2.0f;
}

void updateDistanceSensor() {
  if (millis() - lastSensorRead < SENSOR_INTERVAL_MS) return;
  lastSensorRead = millis();
  distanceCm = measureDistanceCm();

  // Fail safely if there is an obstacle or the sensor has no valid echo.
  // Reverse remains available so the robot can back away.
  if (motorCommand != 'S' && motorCommand != 'B' &&
      (obstacleClose() || !sensorValid())) {
    stopMotors();
    motorCommand = 'S';
    Serial.println(obstacleClose() ? "OBSTACLE: STOP" : "SENSOR INVALID: STOP");
  }
}

void handleStatus() {
  String json = "{\"distanceCm\":" + String(distanceCm, 1);
  json += ",\"sensorOk\":";
  json += sensorValid() ? "true" : "false";
  json += ",\"obstacle\":";
  json += obstacleClose() ? "true" : "false";
  json += ",\"command\":\"";
  json += motorCommand;
  json += "\",\"rssi\":";
  json += (WiFi.status() == WL_CONNECTED) ? String(WiFi.RSSI()) : String(0);
  json += "}";
  sendJson(200, json);
}

void handleCommand() {
  if (!server.hasArg("d")) {
    sendJson(400, "{\"ok\":false,\"error\":\"Missing command\"}");
    return;
  }

  String requested = server.arg("d");
  char direction = 'S';
  if (requested == "F") direction = 'F';
  else if (requested == "B") direction = 'B';
  else if (requested == "L") direction = 'L';
  else if (requested == "R") direction = 'R';

  // Reverse and stop are always allowed; all other movement requires a valid sensor reading
  // and a measured distance greater than 5 cm.
  if (direction != 'B' && direction != 'S' &&
      (!sensorValid() || obstacleClose())) {
    stopMotors();
    motorCommand = 'S';
    sendJson(200, "{\"ok\":false,\"blocked\":true}");
    return;
  }

  driveMotors(direction);
  motorCommand = direction;
  lastCommandTime = millis();
  sendJson(200, "{\"ok\":true,\"blocked\":false}");
}

void handleHeartbeat() {
  if (motorCommand != 'S') lastCommandTime = millis();
  addCorsHeaders();
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "text/plain", "OK");
}

void handleOptions() {
  addCorsHeaders();
  server.send(204, "text/plain", "");
}

void connectNetwork() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to Wi-Fi: ");
  Serial.println(WIFI_SSID);

  unsigned long startTime = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - startTime < 15000UL) {
    delay(300);
    Serial.print('.');
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("Wi-Fi connected.");
    Serial.print("Dashboard API IP: http://");
    Serial.println(WiFi.localIP());
    return;
  }

  Serial.println("Router connection failed; starting fallback AP.");
  WiFi.disconnect(true);
  WiFi.mode(WIFI_AP);
  networkStartedAsAP = WiFi.softAP(AP_SSID, AP_PASSWORD);
  if (networkStartedAsAP) {
    Serial.print("Fallback Wi-Fi: "); Serial.println(AP_SSID);
    Serial.print("Fallback password: "); Serial.println(AP_PASSWORD);
    Serial.print("API IP: http://"); Serial.println(WiFi.softAPIP());
  } else {
    Serial.println("Fallback AP could not start.");
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(IN1_PIN, OUTPUT); pinMode(IN2_PIN, OUTPUT);
  pinMode(IN3_PIN, OUTPUT); pinMode(IN4_PIN, OUTPUT);
  pinMode(TRIG_PIN, OUTPUT); pinMode(ECHO_PIN, INPUT);
  stopMotors();
  motorCommand = 'S';
  distanceCm = measureDistanceCm();
  lastSensorRead = millis();

  connectNetwork();

  server.on("/status", HTTP_GET, handleStatus);
  server.on("/cmd", HTTP_GET, handleCommand);
  server.on("/heartbeat", HTTP_GET, handleHeartbeat);
  server.on("/status", HTTP_OPTIONS, handleOptions);
  server.on("/cmd", HTTP_OPTIONS, handleOptions);
  server.on("/heartbeat", HTTP_OPTIONS, handleOptions);
  server.onNotFound([]() {
    addCorsHeaders();
    server.send(404, "text/plain", "Not found. Available endpoints: /status, /cmd?d=F, /heartbeat");
  });

  server.begin();
  Serial.println("Robot dashboard API started. Motors stopped.");
}

void loop() {
  server.handleClient();
  updateDistanceSensor();

  if (motorCommand != 'S' && millis() - lastCommandTime > COMMAND_TIMEOUT_MS) {
    stopMotors();
    motorCommand = 'S';
    Serial.println("COMMAND TIMEOUT: MOTOR STOPPED");
  }
  delay(2);
}
