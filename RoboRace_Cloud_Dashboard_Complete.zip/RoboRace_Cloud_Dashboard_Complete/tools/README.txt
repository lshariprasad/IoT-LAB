Optional local development tools

PHP syntax check: find public_html -name '*.php' -print0 | xargs -0 -n1 php -l

Do not upload tools or tests files to the public document root unless you need them for private development.
