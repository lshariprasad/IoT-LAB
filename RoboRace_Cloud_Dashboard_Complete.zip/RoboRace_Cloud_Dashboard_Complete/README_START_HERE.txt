ROBORACE CLOUD DASHBOARD — START HERE
====================================

Package contents
- public_html/ : files to upload into the domain's actual document root.
- private/ : server configuration and JSON storage; upload OUTSIDE the public document root.
- firmware/ : ESP32 cloud integration candidate for the earlier 2 x BTS7960 pin map.
- tests/ : endpoint/test notes.
- HOSTINGER_DEPLOYMENT.md : step-by-step FileZilla deployment.
- TESTING_AND_TROUBLESHOOTING.md : validation steps and common problems.

INITIAL LOGIN (change before sharing the site)
Dashboard username: admin
Initial dashboard password: 4y-CBD7WnJtvC7H5qUD_gw
See private/DEPLOYMENT_SECRETS.txt locally for the device API token. Do not upload this secrets file to the server.

IMPORTANT HARDWARE COMPATIBILITY
The firmware provided here matches the earlier ESP32 + two BTS7960/IBT-2 setup and these pins:
Driver 1: RPWM 25, LPWM 26, R_EN 27, L_EN 14
Driver 2: RPWM 18, LPWM 19, R_EN 21, L_EN 22
It is not compatible as-is with the separate README architecture that uses FlySky FS-iA6B -> Cytron MDDS10 -> four motors and no microcontroller in the signal chain. Do NOT flash it on that different architecture. Send the actual current source sketch for an exact merge.

This package has not been uploaded to Hostinger, and the physical robot has not been tested. PHP syntax is checked separately; firmware compilation and hardware tests remain for you to perform. Cloud driving is for low-speed testing only. Keep a physical battery disconnect available.
