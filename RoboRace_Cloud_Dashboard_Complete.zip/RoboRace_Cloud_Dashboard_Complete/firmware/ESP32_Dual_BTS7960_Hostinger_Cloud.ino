/*
  RoboRace Hostinger Cloud Integration - ESP32 + 2 x IBT-2 / BTS7960

  INTEGRATION CANDIDATE, NOT A PATCH OF UNUPLOADED SOURCE.
  Pin map matches the earlier dual-BTS7960 sketch supplied in this conversation:
    Driver 1: RPWM 25, LPWM 26, R_EN 27, L_EN 14
    Driver 2: RPWM 18, LPWM 19, R_EN 21, L_EN 22

  Cloud control is for low-speed bench testing only. Public-internet latency varies.
  Keep a physical battery disconnect within reach. Cloud E-stop is not safety-rated.

  Required Arduino libraries:
    - ArduinoJson (v6 or v7)
  Board package: Espressif Arduino-ESP32 2.x/3.x (both PWM APIs handled below).
*/
#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <esp_arduino_version.h>
#include "root_ca.h"

// ================= CONFIGURATION =================
const char* WIFI_SSID = "SSE-EEE";
const char* WIFI_PASSWORD = "123456789";
const char* BASE_URL = "https://roborace.generai.in";
const char* DEVICE_ID = "roborace-esp32-01";
// Keep this equal to private/config.php -> device_token. Do not publish this sketch with the token.
const char* DEVICE_TOKEN = "0b0f0812eacd8bd45ab8bfde7510d43800ea0dd52b7e4c6af489b97cdc298bf4";
const char* FIRMWARE_VERSION = "rr-cloud-0.1.0";

constexpr uint8_t M1_RPWM = 25, M1_LPWM = 26, M1_REN = 27, M1_LEN = 14;
constexpr uint8_t M2_RPWM = 18, M2_LPWM = 19, M2_REN = 21, M2_LEN = 22;
constexpr uint32_t PWM_FREQUENCY = 20000;
constexpr uint8_t PWM_RESOLUTION = 8;
constexpr int MAX_CLOUD_PWM = 150;  // conservative software limit for cloud control
constexpr int RAMP_STEP = 10;
constexpr uint32_t RAMP_INTERVAL_MS = 10;
constexpr uint32_t POLL_INTERVAL_MS = 600;
constexpr uint32_t REPORT_INTERVAL_MS = 2500;
constexpr uint32_t WIFI_RETRY_INTERVAL_MS = 10000;
constexpr uint32_t CLOUD_FAILSAFE_MS = 1700;
constexpr uint16_t HTTP_TIMEOUT_MS = 2200;

#if ESP_ARDUINO_VERSION_MAJOR < 3
constexpr uint8_t CH_M1_RPWM = 0, CH_M1_LPWM = 1, CH_M2_RPWM = 2, CH_M2_LPWM = 3;
#endif

int targetLeft = 0, targetRight = 0, currentLeft = 0, currentRight = 0;
String lastCommandId = "boot-stop";
String lastAction = "STOP";
String lastCommandResult = "startup_stopped";
bool estopLatched = false;
bool cloudLinkOK = false;
uint32_t lastSuccessfulPollMs = 0;
uint32_t lastPollAttemptMs = 0;
uint32_t lastReportMs = 0;
uint32_t lastRampMs = 0;
uint32_t lastWiFiAttemptMs = 0;

void writePwm(uint8_t pin, uint8_t duty) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(pin, duty);
#else
  if (pin == M1_RPWM) ledcWrite(CH_M1_RPWM, duty);
  else if (pin == M1_LPWM) ledcWrite(CH_M1_LPWM, duty);
  else if (pin == M2_RPWM) ledcWrite(CH_M2_RPWM, duty);
  else if (pin == M2_LPWM) ledcWrite(CH_M2_LPWM, duty);
#endif
}

bool setupPwm() {
  bool ok = true;
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ok = ledcAttach(M1_RPWM, PWM_FREQUENCY, PWM_RESOLUTION) && ok;
  ok = ledcAttach(M1_LPWM, PWM_FREQUENCY, PWM_RESOLUTION) && ok;
  ok = ledcAttach(M2_RPWM, PWM_FREQUENCY, PWM_RESOLUTION) && ok;
  ok = ledcAttach(M2_LPWM, PWM_FREQUENCY, PWM_RESOLUTION) && ok;
#else
  ledcSetup(CH_M1_RPWM, PWM_FREQUENCY, PWM_RESOLUTION);
  ledcSetup(CH_M1_LPWM, PWM_FREQUENCY, PWM_RESOLUTION);
  ledcSetup(CH_M2_RPWM, PWM_FREQUENCY, PWM_RESOLUTION);
  ledcSetup(CH_M2_LPWM, PWM_FREQUENCY, PWM_RESOLUTION);
  ledcAttachPin(M1_RPWM, CH_M1_RPWM); ledcAttachPin(M1_LPWM, CH_M1_LPWM);
  ledcAttachPin(M2_RPWM, CH_M2_RPWM); ledcAttachPin(M2_LPWM, CH_M2_LPWM);
#endif
  return ok;
}

void driverEnable(bool enabled) {
  digitalWrite(M1_REN, enabled ? HIGH : LOW); digitalWrite(M1_LEN, enabled ? HIGH : LOW);
  digitalWrite(M2_REN, enabled ? HIGH : LOW); digitalWrite(M2_LEN, enabled ? HIGH : LOW);
}

void applyMotor1(int value) {
  value = constrain(value, -255, 255);
  if (value > 0) { writePwm(M1_LPWM, 0); writePwm(M1_RPWM, (uint8_t)value); }
  else if (value < 0) { writePwm(M1_RPWM, 0); writePwm(M1_LPWM, (uint8_t)(-value)); }
  else { writePwm(M1_RPWM, 0); writePwm(M1_LPWM, 0); }
}
void applyMotor2(int value) {
  value = constrain(value, -255, 255);
  if (value > 0) { writePwm(M2_LPWM, 0); writePwm(M2_RPWM, (uint8_t)value); }
  else if (value < 0) { writePwm(M2_RPWM, 0); writePwm(M2_LPWM, (uint8_t)(-value)); }
  else { writePwm(M2_RPWM, 0); writePwm(M2_LPWM, 0); }
}
void stopNow(const char* reason, bool disableDriver = false) {
  targetLeft = targetRight = currentLeft = currentRight = 0;
  applyMotor1(0); applyMotor2(0);
  if (disableDriver) driverEnable(false);
  lastCommandResult = reason;
  lastAction = estopLatched ? "ESTOP" : "STOP";
}
int rampToward(int current, int target) {
  if (current != 0 && target != 0 && ((current > 0) != (target > 0))) {
    if (abs(current) <= RAMP_STEP) return 0;
    return current > 0 ? current - RAMP_STEP : current + RAMP_STEP;
  }
  if (current < target) return min(current + RAMP_STEP, target);
  if (current > target) return max(current - RAMP_STEP, target);
  return current;
}
void setTargetsForAction(const String& action, int speed) {
  speed = constrain(speed, 0, MAX_CLOUD_PWM);
  int left = 0, right = 0;
  if (action == "FORWARD") { left = speed; right = speed; }
  else if (action == "REVERSE") { left = -speed; right = -speed; }
  else if (action == "LEFT") { left = -speed; right = speed; }
  else if (action == "RIGHT") { left = speed; right = -speed; }
  targetLeft = left; targetRight = right;
  if (left != 0 || right != 0) driverEnable(true);
}

String endpoint(const char* path) { return String(BASE_URL) + path; }
void configureTls(WiFiClientSecure& client) {
  client.setCACert(ROBO_RACE_ROOT_CA);  // verified TLS; do not replace with setInsecure() in production
  client.setTimeout(HTTP_TIMEOUT_MS);
}

bool postJson(const char* path, const String& body, String& responseBody) {
  if (WiFi.status() != WL_CONNECTED) return false;
  WiFiClientSecure tls;
  configureTls(tls);
  HTTPClient http;
  http.setTimeout(HTTP_TIMEOUT_MS);
  http.setReuse(false);
  if (!http.begin(tls, endpoint(path))) { Serial.println("HTTP begin failed"); return false; }
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Accept", "application/json");
  http.addHeader("X-Device-Token", DEVICE_TOKEN);
  int code = http.POST(body);
  responseBody = code > 0 ? http.getString() : String();
  if (code < 200 || code >= 300) {
    Serial.printf("HTTP %s -> %d\n", path, code);
    if (responseBody.length()) Serial.println(responseBody);
    http.end();
    return false;
  }
  http.end();
  return true;
}

void processCommand(const JsonDocument& doc) {
  const char* idPtr = doc["command_id"] | "";
  const char* actionPtr = doc["action"] | "STOP";
  String id(idPtr), action(actionPtr);
  int speed = doc["speed"] | 0;
  bool serverEstop = doc["estop_latched"] | false;
  const char* allowed[] = {"FORWARD","REVERSE","LEFT","RIGHT","STOP","ESTOP"};
  bool valid = false;
  for (const char* a : allowed) if (action == a) valid = true;
  if (!valid) {
    stopNow("invalid_command", true);
    Serial.println("Rejected unknown command from server");
    return;
  }
  if (speed < 0 || speed > MAX_CLOUD_PWM) {
    stopNow("invalid_speed", true);
    Serial.println("Rejected out-of-range speed from server");
    return;
  }
  if (serverEstop || action == "ESTOP") {
    estopLatched = true;
    lastCommandId = id; lastAction = "ESTOP";
    stopNow("estop_latched", true);
    Serial.println("E-STOP LATCHED by cloud command");
    return;
  }
  // A server response with estop_latched=false explicitly clears a prior cloud latch,
  // but never applies movement on reconnect; CLEAR_ESTOP is returned as STOP.
  if (estopLatched) {
    estopLatched = false;
    stopNow("estop_cleared_still_stopped", true);
  }
  if (id == lastCommandId && action == lastAction) return;
  lastCommandId = id;
  lastAction = action;
  if (action == "STOP") {
    targetLeft = targetRight = 0;
    lastCommandResult = "stop_command_received";
  } else {
    setTargetsForAction(action, speed);
    lastCommandResult = "command_applied_by_firmware";
  }
  Serial.printf("Command %s | action=%s | speed=%d\n", id.c_str(), action.c_str(), speed);
}

void pollCloud() {
  StaticJsonDocument<256> request;
  request["device_id"] = DEVICE_ID;
  request["last_command_id"] = lastCommandId;
  String payload; serializeJson(request, payload);
  String response;
  if (!postJson("/device/poll.php", payload, response)) {
    cloudLinkOK = false;
    return;
  }
  StaticJsonDocument<1024> doc;
  DeserializationError err = deserializeJson(doc, response);
  if (err || !(doc["ok"] | false) || String((const char*)(doc["device_id"] | "")) != DEVICE_ID) {
    Serial.println("Invalid cloud poll JSON/device ID"); cloudLinkOK = false; return;
  }
  lastSuccessfulPollMs = millis();
  cloudLinkOK = true;
  processCommand(doc);
}

void reportStatus() {
  StaticJsonDocument<640> doc;
  doc["device_id"] = DEVICE_ID;
  doc["rssi"] = (WiFi.status() == WL_CONNECTED) ? WiFi.RSSI() : -127;
  doc["uptime_s"] = millis() / 1000UL;
  doc["free_heap"] = ESP.getFreeHeap();
  doc["firmware_version"] = FIRMWARE_VERSION;
  doc["control_mode"] = (WiFi.status() == WL_CONNECTED && cloudLinkOK) ? "cloud" : "stopped";
  doc["left_pwm"] = currentLeft;
  doc["right_pwm"] = currentRight;
  doc["last_command_id"] = lastCommandId;
  doc["last_command"] = lastAction;
  doc["last_command_result"] = lastCommandResult;
  String payload; serializeJson(doc, payload);
  String response;
  if (!postJson("/device/report.php", payload, response)) Serial.println("Status report failed; retrying next interval");
}

void startWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  lastWiFiAttemptMs = millis();
  Serial.printf("Connecting to Wi-Fi SSID: %s\n", WIFI_SSID);
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println(); Serial.println("RoboRace ESP32 Hostinger Cloud Integration");
  pinMode(M1_REN, OUTPUT); pinMode(M1_LEN, OUTPUT); pinMode(M2_REN, OUTPUT); pinMode(M2_LEN, OUTPUT);
  driverEnable(false);
  bool pwmOK = setupPwm();
  applyMotor1(0); applyMotor2(0);
  if (!pwmOK) Serial.println("WARNING: PWM setup returned failure; motor test prohibited until checked.");
  Serial.println("Boot safety: motor drivers disabled; outputs zero.");
  Serial.println("Verify the website TLS CA before testing cloud commands.");
  startWifi();
  lastPollAttemptMs = millis() - POLL_INTERVAL_MS;
  lastReportMs = millis();
  lastRampMs = millis();
}

void loop() {
  uint32_t now = millis();
  if (WiFi.status() != WL_CONNECTED) {
    cloudLinkOK = false;
    if (currentLeft != 0 || currentRight != 0 || targetLeft != 0 || targetRight != 0) stopNow("wifi_lost_failsafe", true);
    if (now - lastWiFiAttemptMs >= WIFI_RETRY_INTERVAL_MS) startWifi();
  } else {
    if (now - lastPollAttemptMs >= POLL_INTERVAL_MS) {
      lastPollAttemptMs = now;
      pollCloud();
    }
    if (now - lastReportMs >= REPORT_INTERVAL_MS) {
      lastReportMs = now;
      reportStatus();
    }
  }
  // Stop if authenticated cloud polls stop arriving, even if old PWM targets remain set.
  if ((currentLeft != 0 || currentRight != 0 || targetLeft != 0 || targetRight != 0) &&
      (lastSuccessfulPollMs == 0 || (uint32_t)(now - lastSuccessfulPollMs) > CLOUD_FAILSAFE_MS)) {
    stopNow("cloud_poll_timeout_failsafe", true);
  }
  if (now - lastRampMs >= RAMP_INTERVAL_MS) {
    lastRampMs = now;
    currentLeft = rampToward(currentLeft, targetLeft);
    currentRight = rampToward(currentRight, targetRight);
    applyMotor1(currentLeft); applyMotor2(currentRight);
  }
  delay(1); // short yield; no long blocking control delay
}
