PRIVATE SERVER FILES

Upload config.php and the storage/ directory as a sibling of the domain's public_html folder, not inside public_html. The DEPLOYMENT_SECRETS.txt file is for your local computer only; do not upload it anywhere on the server.
The config.php file contains the dashboard password hash and device API token. Never publish it.
The storage folder must be writable by PHP; start with the hosting account's normal file permissions (usually directories 750/755 and files 640/644 depending on Hostinger's setup). Do not use 777 unless Hostinger support explicitly instructs you to.
