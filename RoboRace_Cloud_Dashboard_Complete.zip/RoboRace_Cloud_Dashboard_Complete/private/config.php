<?php
declare(strict_types=1);

// This file MUST stay outside the public web root.
return [
    'site_name' => 'RoboRace Cloud',
    'device_id' => 'roborace-esp32-01',
    'device_token' => '0b0f0812eacd8bd45ab8bfde7510d43800ea0dd52b7e4c6af489b97cdc298bf4',
    'dashboard_username' => 'admin',
    'dashboard_password_hash' => '$2y$12$CVflXB.b.OrzbHSCudpTrOJD6920kqac9bZ9tY9rjdXRuT3MuiOd2',
    'status_timeout_seconds' => 8,
    'command_ttl_ms' => 1300,
    'max_cloud_speed' => 150,
    'storage_dir' => __DIR__ . '/storage',
];
