<?php
declare(strict_types=1);
require dirname(__DIR__) . '/_bootstrap.php';
rr_method('POST');
rr_require_dashboard();
rr_require_csrf();
if (!rr_rate_limit('command', 240, 60)) rr_json(['ok'=>false, 'error'=>'rate_limited'], 429);
global $rr_config;
$data = rr_body_json(4096);
$action = strtoupper(trim((string)($data['action'] ?? '')));
$allowed = ['FORWARD','REVERSE','LEFT','RIGHT','STOP','ESTOP','CLEAR_ESTOP'];
if (!in_array($action, $allowed, true)) rr_json(['ok'=>false, 'error'=>'invalid_action'], 422);
$rawSpeed = $data['speed'] ?? 80;
if (!is_int($rawSpeed) && !(is_string($rawSpeed) && preg_match('/^\d{1,3}$/', $rawSpeed))) rr_json(['ok'=>false, 'error'=>'invalid_speed'], 422);
$speed = (int)$rawSpeed;
$maxSpeed = (int)($rr_config['max_cloud_speed'] ?? 150);
if ($speed < 0 || $speed > $maxSpeed) rr_json(['ok'=>false, 'error'=>'speed_out_of_range', 'max_speed'=>$maxSpeed], 422);
$now = (int)floor(microtime(true) * 1000);
$ttl = (int)($rr_config['command_ttl_ms'] ?? 1300);
$default = rr_default_command();
try {
    $command = rr_update_json('command.json', $default, function(array $old) use ($action, $speed, $now, $ttl): array {
        $latched = !empty($old['estop_latched']);
        if ($action === 'ESTOP') {
            return ['id'=>bin2hex(random_bytes(10)), 'action'=>'ESTOP', 'speed'=>0, 'created_at_ms'=>$now, 'expires_at_ms'=>0, 'estop_latched'=>true, 'server_state'=>'accepted_by_server'];
        }
        if ($action === 'CLEAR_ESTOP') {
            return ['id'=>bin2hex(random_bytes(10)), 'action'=>'STOP', 'speed'=>0, 'created_at_ms'=>$now, 'expires_at_ms'=>0, 'estop_latched'=>false, 'server_state'=>'estop_cleared_still_stopped'];
        }
        if ($latched) {
            return ['id'=>(string)($old['id'] ?? 'estop'), 'action'=>'ESTOP', 'speed'=>0, 'created_at_ms'=>(int)($old['created_at_ms'] ?? $now), 'expires_at_ms'=>0, 'estop_latched'=>true, 'server_state'=>'rejected_while_estop_latched'];
        }
        if ($action === 'STOP' || $speed === 0) {
            return ['id'=>bin2hex(random_bytes(10)), 'action'=>'STOP', 'speed'=>0, 'created_at_ms'=>$now, 'expires_at_ms'=>0, 'estop_latched'=>false, 'server_state'=>'accepted_by_server'];
        }
        return ['id'=>bin2hex(random_bytes(10)), 'action'=>$action, 'speed'=>$speed, 'created_at_ms'=>$now, 'expires_at_ms'=>$now + $ttl, 'estop_latched'=>false, 'server_state'=>'accepted_by_server'];
    });
} catch (Throwable $e) {
    rr_json(['ok'=>false, 'error'=>'storage_unavailable'], 503);
}
if (!empty($command['estop_latched']) && $action !== 'ESTOP' && $action !== 'CLEAR_ESTOP') {
    rr_json(['ok'=>false, 'error'=>'estop_latched', 'command_id'=>$command['id'], 'state'=>'rejected'], 423);
}
rr_json(['ok'=>true, 'accepted'=>true, 'delivery'=>'pending_device_poll', 'command_id'=>$command['id'], 'action'=>$command['action'], 'speed'=>(int)$command['speed'], 'estop_latched'=>(bool)$command['estop_latched'], 'expires_at_ms'=>(int)$command['expires_at_ms'], 'state'=>$command['server_state']]);
