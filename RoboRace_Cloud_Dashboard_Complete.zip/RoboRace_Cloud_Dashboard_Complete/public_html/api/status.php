<?php
declare(strict_types=1);
require dirname(__DIR__) . '/_bootstrap.php';
rr_method('GET');
rr_require_dashboard();
global $rr_config;
$status = rr_read_json('status.json', []);
$command = rr_command_current();
$now = time();
$lastSeen = (int)($status['last_seen_ts'] ?? 0);
$online = $lastSeen > 0 && ($now - $lastSeen) <= (int)($rr_config['status_timeout_seconds'] ?? 8);
$lastReport = (int)($status['last_report_ts'] ?? 0);
$device = [
    'device_id' => $status['device_id'] ?? null,
    'online' => $online,
    'last_seen_ts' => $lastSeen ?: null,
    'last_seen_iso' => $status['last_seen_iso'] ?? null,
    'last_report_ts' => $lastReport ?: null,
    'last_report_iso' => $status['last_report_iso'] ?? null,
    'rssi' => $status['rssi'] ?? null,
    'uptime_s' => $status['uptime_s'] ?? null,
    'free_heap' => $status['free_heap'] ?? null,
    'firmware_version' => $status['firmware_version'] ?? null,
    'control_mode' => $status['control_mode'] ?? null,
    'left_pwm' => $status['left_pwm'] ?? null,
    'right_pwm' => $status['right_pwm'] ?? null,
    'last_command_id' => $status['last_command_id'] ?? null,
    'last_command' => $status['last_command'] ?? null,
    'last_command_result' => $status['last_command_result'] ?? null,
];
$command['is_expired'] = in_array($command['action'] ?? '', ['FORWARD','REVERSE','LEFT','RIGHT'], true) && (int)($command['expires_at_ms'] ?? 0) < (int)floor(microtime(true)*1000);
rr_json(['ok'=>true, 'server_time'=>gmdate('c'), 'server_time_ms'=>(int)floor(microtime(true)*1000), 'device'=>$device, 'command'=>$command, 'max_cloud_speed'=>(int)($rr_config['max_cloud_speed'] ?? 150), 'status_timeout_seconds'=>(int)($rr_config['status_timeout_seconds'] ?? 8)]);
