<?php
declare(strict_types=1);
require __DIR__ . '/_bootstrap.php';
rr_json(['ok'=>true, 'service'=>'roborace-cloud', 'php'=>PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION]);
