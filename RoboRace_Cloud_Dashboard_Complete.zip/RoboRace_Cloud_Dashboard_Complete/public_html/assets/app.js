(() => {
'use strict';
const $ = (id) => document.getElementById(id);
const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
const speedRange = $('speedRange');
let activeMove = null;
let repeatTimer = null;
let lastAcceptedId = null;
let lastStatusSignature = '';
let activityCount = 0;
let estopLatched = false;
let latestOnline = false;
const MAX_LOG = 20;

function logEvent(message) {
  const log = $('activityLog');
  if (!log) return;
  const empty = log.querySelector('.empty-log');
  if (empty) empty.remove();
  const item = document.createElement('div');
  item.className = 'log-item';
  const time = document.createElement('span');
  time.className = 'log-time';
  time.textContent = new Date().toLocaleTimeString();
  const text = document.createElement('span');
  text.className = 'log-text';
  text.textContent = message;
  item.append(time, text);
  log.prepend(item);
  activityCount++;
  while (log.children.length > MAX_LOG) log.lastElementChild.remove();
}
function feedback(message, type='') {
  const el = $('commandFeedback');
  if (!el) return;
  el.className = 'command-feedback' + (type ? ' ' + type : '');
  const span = el.querySelector('span:last-child');
  if (span) span.textContent = message;
}
function setSpeedLabel() { $('speedLabel').textContent = `${speedRange.value} / 150`; }
async function apiCommand(action, speed) {
  try {
    const response = await fetch('/api/command.php', {
      method: 'POST', credentials: 'same-origin', cache: 'no-store',
      headers: {'Content-Type':'application/json', 'X-CSRF-Token':csrf},
      body: JSON.stringify({action, speed})
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok || !body.ok) {
      const message = body.error || `server_http_${response.status}`;
      feedback(`Command not accepted: ${message}`, 'bad');
      logEvent(`${action} rejected by server (${message})`);
      return false;
    }
    lastAcceptedId = body.command_id || null;
    $('lastCommand').textContent = body.action || action;
    $('commandId').textContent = body.command_id || '—';
    $('commandState').textContent = body.delivery === 'pending_device_poll' ? 'Accepted · delivery pending' : (body.state || 'accepted');
    feedback(`Accepted by server; waiting for device acknowledgement (${body.command_id}).`, 'good');
    if (action === 'ESTOP') { estopLatched = true; renderEstop(); }
    if (action === 'CLEAR_ESTOP') { estopLatched = false; renderEstop(); }
    logEvent(`${action} accepted by server · ${body.command_id}`);
    return true;
  } catch (e) {
    feedback('Server unreachable. No execution is confirmed.', 'bad');
    logEvent(`${action} failed: server unreachable`);
    return false;
  }
}
function beginMove(action) {
  if (estopLatched) { feedback('E-stop is latched. Clear it while stopped before issuing movement.', 'bad'); return; }
  if (!latestOnline) { feedback('Robot is offline or has not reported yet. Cloud movement is disabled.', 'bad'); return; }
  if (activeMove === action) return;
  stopRepeaterOnly();
  activeMove = action;
  document.querySelectorAll('[data-move]').forEach(b => b.classList.toggle('held', b.dataset.move === action));
  const send = () => apiCommand(action, Number(speedRange.value));
  send();
  repeatTimer = window.setInterval(send, 400);
}
function stopRepeaterOnly() {
  if (repeatTimer) window.clearInterval(repeatTimer);
  repeatTimer = null;
  activeMove = null;
  document.querySelectorAll('[data-move]').forEach(b => b.classList.remove('held'));
}
function stopMove(sendStop=true) {
  const wasMoving = activeMove !== null;
  stopRepeaterOnly();
  if (sendStop && (wasMoving || !estopLatched)) apiCommand('STOP', 0);
}
function renderEstop() {
  $('estopState').classList.toggle('latched', estopLatched);
  $('estopState').querySelector('span:last-child').textContent = estopLatched ? 'E-stop LATCHED — movement blocked' : 'E-stop clear — robot remains stopped';
  $('estopButton').disabled = estopLatched;
  $('clearEstopButton').disabled = !estopLatched;
}
function fmtTime(ts) {
  if (!ts) return 'Never received';
  const date = new Date(ts * 1000);
  return Number.isNaN(date.getTime()) ? 'Unavailable' : date.toLocaleString();
}
function fmtDuration(s) {
  if (!Number.isFinite(Number(s))) return 'Unavailable';
  s = Math.max(0, Math.floor(Number(s)));
  const h = Math.floor(s/3600), m = Math.floor((s%3600)/60), sec = s%60;
  return h ? `${h}h ${m}m ${sec}s` : (m ? `${m}m ${sec}s` : `${sec}s`);
}
function setPwm(value, valueId, meterId) {
  if (value === null || value === undefined || !Number.isFinite(Number(value))) {
    $(valueId).textContent = '—'; $(meterId).style.width = '0%'; return;
  }
  const n = Number(value);
  $(valueId).textContent = `${n} PWM`;
  $(meterId).style.width = `${Math.min(100, Math.abs(n)/255*100)}%`;
}
async function pollStatus() {
  try {
    const response = await fetch('/api/status.php', {credentials:'same-origin', cache:'no-store'});
    if (response.status === 401) { window.location.href='/'; return; }
    if (!response.ok) throw new Error(`status_http_${response.status}`);
    const s = await response.json();
    if (!s.ok) throw new Error(s.error || 'status_not_ok');
    const d = s.device || {}, c = s.command || {};
    latestOnline = Boolean(d.online);
    const pill = $('connectionPill');
    pill.classList.toggle('online', latestOnline);
    pill.classList.toggle('offline', !latestOnline && Boolean(d.last_seen_ts));
    $('connectionLabel').textContent = latestOnline ? 'ESP32 online' : (d.last_seen_ts ? 'ESP32 offline' : 'Awaiting first heartbeat');
    $('robotState').textContent = latestOnline ? 'ONLINE' : (d.last_seen_ts ? 'OFFLINE' : 'UNKNOWN');
    $('robotState').style.color = latestOnline ? 'var(--green)' : (d.last_seen_ts ? 'var(--red)' : 'var(--amber)');
    $('lastSeen').textContent = d.last_seen_ts ? `Last heartbeat ${fmtTime(d.last_seen_ts)}` : 'No device heartbeat received';
    $('modeValue').textContent = d.control_mode ? String(d.control_mode).toUpperCase() : '—';
    setPwm(d.left_pwm, 'leftPwm', 'leftMeter'); setPwm(d.right_pwm, 'rightPwm', 'rightMeter');
    $('deviceId').textContent = d.device_id || 'Not connected';
    $('firmwareVersion').textContent = d.firmware_version || 'Unavailable';
    $('rssiValue').textContent = Number.isFinite(Number(d.rssi)) && d.rssi !== null ? `${d.rssi} dBm` : 'Unavailable';
    $('uptimeValue').textContent = d.uptime_s !== null && d.uptime_s !== undefined ? fmtDuration(d.uptime_s) : 'Unavailable';
    $('heapValue').textContent = d.free_heap !== null && d.free_heap !== undefined ? `${Number(d.free_heap).toLocaleString()} bytes` : 'Unavailable';
    $('reportTime').textContent = fmtTime(d.last_report_ts);
    $('lastCommand').textContent = c.action || 'STOP';
    $('commandId').textContent = c.id || '—';
    estopLatched = Boolean(c.estop_latched); renderEstop();
    const acknowledged = c.id && d.last_command_id && c.id === d.last_command_id;
    if (c.estop_latched) $('commandState').textContent = latestOnline ? 'E-stop latched · device response pending/observed' : 'E-stop latched on server · device offline';
    else if (!latestOnline) $('commandState').textContent = 'Not delivered · device offline';
    else if (acknowledged) $('commandState').textContent = `Device reported: ${d.last_command_result || d.last_command || 'acknowledged'}`;
    else $('commandState').textContent = c.server_state === 'expired_to_stop' ? 'Expired to STOP · awaiting device report' : 'Accepted · awaiting device acknowledgement';
    if (lastAcceptedId && d.last_command_id === lastAcceptedId) feedback(`Device reported command ${lastAcceptedId} (${d.last_command_result || d.last_command || 'acknowledged'}).`, 'good');
    $('serverClock').textContent = `Server ${new Date(s.server_time).toLocaleTimeString()} · refresh 1 s`;
    const signature = `${latestOnline}|${c.action}|${Boolean(c.estop_latched)}|${d.last_command_id || ''}|${d.last_command_result || ''}`;
    if (signature !== lastStatusSignature) { if (lastStatusSignature) logEvent(`Status changed · ${latestOnline ? 'online' : 'offline'} · ${c.action || 'STOP'}`); lastStatusSignature=signature; }
    // Fail closed in browser UI after the device goes offline.
    document.querySelectorAll('[data-move]').forEach(b => b.disabled = !latestOnline || estopLatched);
  } catch (e) {
    latestOnline = false;
    $('connectionPill').classList.remove('online'); $('connectionPill').classList.add('offline');
    $('connectionLabel').textContent = 'Dashboard API error'; $('robotState').textContent = 'UNKNOWN';
    $('lastSeen').textContent = 'Status endpoint unavailable';
    feedback('Unable to read authenticated status. No live state can be confirmed.', 'bad');
    document.querySelectorAll('[data-move]').forEach(b => b.disabled = true);
  }
}

document.querySelectorAll('[data-move]').forEach(button => {
  button.addEventListener('pointerdown', e => { e.preventDefault(); if (!button.disabled) beginMove(button.dataset.move); });
  button.addEventListener('contextmenu', e => e.preventDefault());
});
document.addEventListener('pointerup', () => { if (activeMove) stopMove(true); });
document.addEventListener('pointercancel', () => { if (activeMove) stopMove(true); });
$('stopButton').addEventListener('click', () => { stopMove(false); apiCommand('STOP', 0); });
$('estopButton').addEventListener('click', async () => { stopRepeaterOnly(); await apiCommand('ESTOP', 0); });
$('clearEstopButton').addEventListener('click', async () => { stopRepeaterOnly(); await apiCommand('CLEAR_ESTOP', 0); });
speedRange.addEventListener('input', setSpeedLabel);
window.addEventListener('blur', () => { if (activeMove) stopMove(true); });
document.addEventListener('visibilitychange', () => { if (document.hidden && activeMove) stopMove(true); });
window.addEventListener('pagehide', () => { if (activeMove) { try { fetch('/api/command.php', {method:'POST', credentials:'same-origin', cache:'no-store', keepalive:true, headers:{'Content-Type':'application/json','X-CSRF-Token':csrf}, body:JSON.stringify({action:'STOP', speed:0})}); } catch(e) {} stopRepeaterOnly(); } });
window.addEventListener('keydown', e => {
  if (['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)) return;
  const map = {w:'FORWARD', ArrowUp:'FORWARD', s:'REVERSE', ArrowDown:'REVERSE', a:'LEFT', ArrowLeft:'LEFT', d:'RIGHT', ArrowRight:'RIGHT'};
  if (e.code === 'Space' || e.key === 'Escape') { e.preventDefault(); stopMove(false); apiCommand('STOP',0); return; }
  const act = map[e.key] || map[e.key.toLowerCase()];
  if (act) { e.preventDefault(); if (!activeMove) beginMove(act); }
});
window.addEventListener('keyup', e => {
  const directional = ['w','a','s','d','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'];
  if (directional.includes(e.key) && activeMove) stopMove(true);
});
$('clearLogButton').addEventListener('click', () => { $('activityLog').innerHTML = '<div class="empty-log">Log cleared in this browser session.</div>'; activityCount=0; });
setSpeedLabel(); renderEstop();
logEvent('Dashboard session opened. Commands require a live device heartbeat.');
pollStatus(); window.setInterval(pollStatus, 1000);
})();
