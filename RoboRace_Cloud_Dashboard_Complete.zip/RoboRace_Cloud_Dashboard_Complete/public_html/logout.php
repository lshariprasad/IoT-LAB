<?php
declare(strict_types=1);
require __DIR__ . '/_bootstrap.php';
rr_method('POST');
$provided = (string)($_POST['csrf'] ?? '');
$stored = (string)($_SESSION['rr_csrf'] ?? '');
if ($provided === '' || $stored === '' || !hash_equals($stored, $provided)) {
    http_response_code(403); exit('Request rejected.');
}
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', ['expires'=>time()-42000, 'path'=>$p['path'], 'domain'=>$p['domain'], 'secure'=>$p['secure'], 'httponly'=>$p['httponly'], 'samesite'=>'Lax']);
}
session_destroy();
header('Location: /', true, 303);
exit;
