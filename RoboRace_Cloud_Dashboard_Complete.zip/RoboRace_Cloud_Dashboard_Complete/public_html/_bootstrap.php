<?php
declare(strict_types=1);

$rr_config_path = dirname(__DIR__) . '/private/config.php';
if (!is_file($rr_config_path)) {
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    exit('RoboRace setup is incomplete. Upload the private configuration outside the web root. See README_START_HERE.txt.');
}
$rr_config = require $rr_config_path;
if (!is_array($rr_config) || empty($rr_config['storage_dir'])) {
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    exit('RoboRace configuration is invalid.');
}
$rr_storage = (string)$rr_config['storage_dir'];
if (!is_dir($rr_storage) && !@mkdir($rr_storage, 0750, true) && !is_dir($rr_storage)) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    exit('RoboRace storage is unavailable. Check server-side storage permissions.');
}

$is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $is_https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('X-Frame-Options: DENY');
header('Cache-Control: no-store, max-age=0');

function rr_json(array $payload, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, max-age=0');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function rr_method(string $expected): void {
    if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== strtoupper($expected)) {
        header('Allow: ' . strtoupper($expected));
        rr_json(['ok'=>false, 'error'=>'method_not_allowed'], 405);
    }
}
function rr_body_json(int $max_bytes = 8192): array {
    $raw = file_get_contents('php://input', false, null, 0, $max_bytes + 1);
    if ($raw === false || strlen($raw) > $max_bytes) rr_json(['ok'=>false, 'error'=>'request_too_large'], 413);
    $data = json_decode($raw, true);
    if (!is_array($data) || json_last_error() !== JSON_ERROR_NONE) rr_json(['ok'=>false, 'error'=>'invalid_json'], 400);
    return $data;
}
function rr_path(string $name): string {
    global $rr_storage;
    $allowed = ['status.json', 'command.json', 'rate_limits.json'];
    if (!in_array($name, $allowed, true)) throw new RuntimeException('Invalid storage key');
    return $rr_storage . '/' . $name;
}
function rr_read_json(string $name, array $default = []): array {
    $path = rr_path($name);
    if (!is_file($path)) return $default;
    $raw = @file_get_contents($path);
    if ($raw === false) return $default;
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : $default;
}
function rr_update_json(string $name, array $default, callable $mutator): array {
    $path = rr_path($name);
    $lock = @fopen($path . '.lock', 'c+');
    if (!$lock || !flock($lock, LOCK_EX)) {
        if (is_resource($lock)) fclose($lock);
        throw new RuntimeException('Storage lock unavailable');
    }
    try {
        $raw = is_file($path) ? @file_get_contents($path) : false;
        $current = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($current)) $current = $default;
        $updated = $mutator($current);
        if (!is_array($updated)) throw new RuntimeException('Invalid storage update');
        $tmp = $path . '.tmp.' . bin2hex(random_bytes(4));
        $json = json_encode($updated, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if ($json === false || @file_put_contents($tmp, $json, LOCK_EX) === false) {
            @unlink($tmp);
            throw new RuntimeException('Storage write failed');
        }
        @chmod($tmp, 0640);
        if (!@rename($tmp, $path)) {
            @unlink($tmp);
            throw new RuntimeException('Storage replace failed');
        }
        @chmod($path, 0640);
        return $updated;
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}
function rr_default_command(): array {
    return ['id'=>'boot-stop', 'action'=>'STOP', 'speed'=>0, 'created_at_ms'=>(int)floor(microtime(true)*1000), 'expires_at_ms'=>0, 'estop_latched'=>false, 'server_state'=>'idle'];
}
function rr_command_current(): array {
    global $rr_config;
    $now = (int)floor(microtime(true) * 1000);
    $default = rr_default_command();
    try {
        $updated = rr_update_json('command.json', $default, function(array $c) use ($now, $rr_config): array {
            if (!isset($c['id'], $c['action'])) $c = rr_default_command();
            $motion = in_array(($c['action'] ?? 'STOP'), ['FORWARD','REVERSE','LEFT','RIGHT'], true);
            if (!empty($c['estop_latched'])) {
                $c['action'] = 'ESTOP'; $c['speed'] = 0; $c['server_state'] = 'estop_latched';
            } elseif ($motion && (int)($c['expires_at_ms'] ?? 0) < $now) {
                $c = ['id'=>'expire-' . bin2hex(random_bytes(6)), 'action'=>'STOP', 'speed'=>0, 'created_at_ms'=>$now, 'expires_at_ms'=>0, 'estop_latched'=>false, 'server_state'=>'expired_to_stop'];
            }
            return $c;
        });
        return $updated;
    } catch (Throwable $e) {
        return $default;
    }
}
function rr_require_dashboard(): void {
    if (empty($_SESSION['rr_authenticated']) || empty($_SESSION['rr_username'])) {
        rr_json(['ok'=>false, 'error'=>'authentication_required'], 401);
    }
}
function rr_require_csrf(): void {
    $provided = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    $stored = (string)($_SESSION['rr_csrf'] ?? '');
    if ($provided === '' || $stored === '' || !hash_equals($stored, $provided)) {
        rr_json(['ok'=>false, 'error'=>'csrf_validation_failed'], 403);
    }
}
function rr_require_device(): void {
    global $rr_config;
    $provided = (string)($_SERVER['HTTP_X_DEVICE_TOKEN'] ?? '');
    $expected = (string)($rr_config['device_token'] ?? '');
    if ($expected === '' || str_starts_with($expected, 'CHANGE_ME') || $provided === '' || !hash_equals($expected, $provided)) {
        rr_json(['ok'=>false, 'error'=>'device_authentication_failed'], 401);
    }
}
function rr_rate_limit(string $bucket, int $limit, int $window_seconds): bool {
    $key = hash('sha256', $bucket . '|' . (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    $now = time();
    $records = rr_read_json('rate_limits.json', []);
    $entry = $records[$key] ?? ['start'=>$now, 'count'=>0];
    if (($now - (int)($entry['start'] ?? 0)) >= $window_seconds) $entry = ['start'=>$now, 'count'=>0];
    $entry['count'] = (int)$entry['count'] + 1;
    $records[$key] = $entry;
    // Prune old entries to keep the file bounded.
    foreach ($records as $k => $v) if (($now - (int)($v['start'] ?? 0)) > 86400) unset($records[$k]);
    try { rr_update_json('rate_limits.json', [], fn(array $unused): array => $records); } catch (Throwable $e) { /* fail closed below only for login/command separately */ }
    return (int)$entry['count'] <= $limit;
}
function rr_iso(int $epoch_seconds): ?string {
    return $epoch_seconds > 0 ? gmdate('c', $epoch_seconds) : null;
}
