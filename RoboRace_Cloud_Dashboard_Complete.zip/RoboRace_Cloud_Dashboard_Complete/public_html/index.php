<?php
declare(strict_types=1);
require __DIR__ . '/_bootstrap.php';
if (empty($_SESSION['rr_authenticated'])) {
    if (empty($_SESSION['rr_csrf'])) $_SESSION['rr_csrf'] = bin2hex(random_bytes(32));
    $csrf = htmlspecialchars((string)$_SESSION['rr_csrf'], ENT_QUOTES, 'UTF-8');
    $error = isset($_GET['error']) ? 'Login failed. Check credentials or wait before trying again.' : '';
    ?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#0a1020"><title>RoboRace Cloud · Sign in</title><link rel="stylesheet" href="/assets/style.css"></head><body class="auth-body"><main class="auth-shell"><div class="brand-mark">RR<span>+</span></div><p class="eyebrow">ROBOTICS CONTROL PLATFORM</p><h1>RoboRace <span>Cloud</span></h1><p class="muted">Secure dashboard for your connected robot.</p><?php if ($error !== ''): ?><div class="alert danger"><?=htmlspecialchars($error, ENT_QUOTES, 'UTF-8')?></div><?php endif; ?><form method="post" action="/login.php" class="auth-form"><input type="hidden" name="csrf" value="<?=$csrf?>"><label for="username">Username</label><input id="username" name="username" autocomplete="username" maxlength="64" required><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" required><button class="btn primary full" type="submit">Sign in <span aria-hidden="true">→</span></button></form><p class="micro muted">Private access only. Use HTTPS and keep the device token confidential.</p></main></body></html><?php
    exit;
}
if (empty($_SESSION['rr_csrf'])) $_SESSION['rr_csrf'] = bin2hex(random_bytes(32));
$csrf = htmlspecialchars((string)$_SESSION['rr_csrf'], ENT_QUOTES, 'UTF-8');
$username = htmlspecialchars((string)($_SESSION['rr_username'] ?? 'admin'), ENT_QUOTES, 'UTF-8');
?><!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#0a1020"><meta name="csrf-token" content="<?=$csrf?>">
<title>RoboRace Cloud · Control Room</title><link rel="stylesheet" href="/assets/style.css"><script src="/assets/app.js" defer></script>
</head><body>
<div class="app-shell">
<aside class="sidebar"><div class="brand"><div class="brand-mark">RR<span>+</span></div><div><strong>ROBORACE</strong><small>CLOUD CONTROL</small></div></div><div class="side-label">CONTROL ROOM</div><div class="nav-item active"><span class="nav-icon">◈</span> Overview</div><div class="side-note"><span class="pulse-dot"></span><div><strong>Device channel</strong><small>HTTPS · token-authenticated</small></div></div><div class="sidebar-bottom"><div class="avatar">RR</div><div class="profile"><strong><?=$username?></strong><small>Dashboard operator</small></div><form method="post" action="/logout.php"><input type="hidden" name="csrf" value="<?=$csrf?>"><button class="icon-btn" title="Sign out" aria-label="Sign out">↗</button></form></div></aside>
<main class="main-content">
<header class="topbar"><div><p class="eyebrow">LIVE OPERATIONS / 01</p><h1>Control <span>Room</span></h1><p class="muted">Monitor the latest device report and send short, explicit commands.</p></div><div class="top-status" id="connectionPill"><span class="status-led"></span><span id="connectionLabel">Checking device…</span></div></header>
<div class="safety-banner"><div class="safety-icon">!</div><div><strong>Cloud commands are not safety-rated.</strong><p>Internet latency can vary. Test only at low speed with wheels raised first. Keep a physical power disconnect within reach; the website E-stop is not a hardware emergency stop.</p></div></div>
<section class="status-grid" aria-label="Device status">
<article class="stat-card"><div class="stat-head"><span>ROBOT LINK</span><span class="stat-symbol">⌁</span></div><div class="stat-value" id="robotState">UNKNOWN</div><div class="stat-foot" id="lastSeen">Waiting for a device report</div></article>
<article class="stat-card"><div class="stat-head"><span>CONTROL MODE</span><span class="stat-symbol">◎</span></div><div class="stat-value" id="modeValue">—</div><div class="stat-foot">Reported by firmware</div></article>
<article class="stat-card"><div class="stat-head"><span>LEFT PWM</span><span class="stat-symbol">↖</span></div><div class="stat-value" id="leftPwm">—</div><div class="meter"><span id="leftMeter"></span></div><div class="stat-foot">Actual reported output</div></article>
<article class="stat-card"><div class="stat-head"><span>RIGHT PWM</span><span class="stat-symbol">↗</span></div><div class="stat-value" id="rightPwm">—</div><div class="meter"><span id="rightMeter"></span></div><div class="stat-foot">Actual reported output</div></article>
</section>
<section class="main-grid">
<article class="panel drive-panel"><div class="panel-title"><div><p class="eyebrow">MANUAL COMMANDS</p><h2>Drive interface</h2></div><span class="tag" id="commandModeTag">HOLD TO MOVE</span></div><p class="muted small">Press and hold a direction. Releasing sends STOP. Command delivery depends on the internet and device polling.</p>
<div class="drive-pad" aria-label="Movement controls"><div></div><button class="drive-btn" data-move="FORWARD" aria-label="Forward"><span>▲</span><small>FORWARD</small></button><div></div><button class="drive-btn" data-move="LEFT" aria-label="Left"><span>◀</span><small>LEFT</small></button><button class="drive-btn stop-btn" id="stopButton" aria-label="Stop"><span>■</span><small>STOP</small></button><button class="drive-btn" data-move="RIGHT" aria-label="Right"><span>▶</span><small>RIGHT</small></button><div></div><button class="drive-btn" data-move="REVERSE" aria-label="Reverse"><span>▼</span><small>REVERSE</small></button><div></div></div>
<div class="speed-line"><label for="speedRange">Command speed <strong id="speedLabel">80 / 150</strong></label><span class="muted micro">PWM command · limited for cloud tests</span></div><input type="range" id="speedRange" min="60" max="150" step="5" value="80"><div class="range-labels"><span>LOW</span><span>MAX CLOUD PWM</span></div>
<div class="keyboard-hint"><span>⌨</span> Keyboard: W A S D / arrow keys · Space or Esc = STOP</div>
<div class="command-feedback" id="commandFeedback" role="status" aria-live="polite"><span class="feedback-dot"></span><span>Commands are locked until device status is checked.</span></div>
</article>
<article class="panel safety-panel"><div class="panel-title"><div><p class="eyebrow">SAFETY OVERRIDE</p><h2>Emergency stop</h2></div><span class="estop-symbol">!</span></div><p class="muted small">Latches a STOP state on the server so movement requests are rejected until you explicitly clear it. The ESP32 must be online to receive the change.</p><button class="btn emergency full" id="estopButton"><span>■</span> ACTIVATE E-STOP</button><button class="btn outline full" id="clearEstopButton" disabled>Clear latch (remain stopped)</button><div class="estop-state" id="estopState"><span class="status-led"></span><span>E-stop state unknown</span></div><div class="divider"></div><div class="info-row"><span>Last command</span><strong id="lastCommand">STOP</strong></div><div class="info-row"><span>Command state</span><strong id="commandState">No device acknowledgement</strong></div><div class="info-row"><span>Command ID</span><code id="commandId">—</code></div><p class="micro muted">This cloud E-stop cannot cut battery power and should never replace a physical disconnect.</p></article>
</section>
<section class="detail-grid">
<article class="panel"><div class="panel-title"><div><p class="eyebrow">TELEMETRY</p><h2>Device details</h2></div><span class="tag subtle">REAL REPORTS ONLY</span></div><div class="detail-list"><div><span>Device ID</span><strong id="deviceId">—</strong></div><div><span>Firmware</span><strong id="firmwareVersion">Unavailable</strong></div><div><span>Wi-Fi RSSI</span><strong id="rssiValue">Unavailable</strong></div><div><span>Uptime</span><strong id="uptimeValue">Unavailable</strong></div><div><span>Free heap</span><strong id="heapValue">Unavailable</strong></div><div><span>Last firmware report</span><strong id="reportTime">Never received</strong></div></div><div class="no-sensor-note">Battery voltage, battery percentage and external sensors are not displayed because this firmware has no corresponding measurement inputs.</div></article>
<article class="panel"><div class="panel-title"><div><p class="eyebrow">SYSTEM EVENTS</p><h2>Activity log</h2></div><button class="text-btn" id="clearLogButton">Clear</button></div><div class="activity-log" id="activityLog"><div class="empty-log">No events yet. Dashboard events appear here.</div></div></article>
</section>
<footer class="footer"><span>ROBORACE CLOUD / HOSTINGER PHP</span><span id="serverClock">Updating status…</span><span>Manual control · No autonomous steering</span></footer>
</main></div>
</body></html>
