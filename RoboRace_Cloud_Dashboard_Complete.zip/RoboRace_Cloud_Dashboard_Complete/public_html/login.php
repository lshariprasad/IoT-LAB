<?php
declare(strict_types=1);
require __DIR__ . '/_bootstrap.php';
rr_method('POST');
if (!rr_rate_limit('login', 8, 300)) { header('Location: /?error=1', true, 303); exit; }
$providedCsrf = (string)($_POST['csrf'] ?? '');
$storedCsrf = (string)($_SESSION['rr_csrf'] ?? '');
$username = trim((string)($_POST['username'] ?? ''));
$password = (string)($_POST['password'] ?? '');
$validCsrf = $providedCsrf !== '' && $storedCsrf !== '' && hash_equals($storedCsrf, $providedCsrf);
$validUser = hash_equals((string)($rr_config['dashboard_username'] ?? ''), $username);
$validPassword = password_verify($password, (string)($rr_config['dashboard_password_hash'] ?? ''));
if (!$validCsrf || !$validUser || !$validPassword) {
    usleep(250000);
    header('Location: /?error=1', true, 303);
    exit;
}
session_regenerate_id(true);
$_SESSION['rr_authenticated'] = true;
$_SESSION['rr_username'] = $username;
$_SESSION['rr_csrf'] = bin2hex(random_bytes(32));
header('Location: /', true, 303);
exit;
