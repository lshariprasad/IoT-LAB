<?php
declare(strict_types=1);
require dirname(__DIR__) . '/_bootstrap.php';
rr_method('POST');
rr_require_device();
global $rr_config;
$data = rr_body_json(4096);
$deviceId = (string)($data['device_id'] ?? '');
if (!hash_equals((string)$rr_config['device_id'], $deviceId)) rr_json(['ok'=>false, 'error'=>'device_id_mismatch'], 403);
$now = time();
try {
    rr_update_json('status.json', [], function(array $s) use ($deviceId, $now): array {
        $s['device_id'] = $deviceId;
        $s['last_seen_ts'] = $now;
        $s['last_seen_iso'] = gmdate('c', $now);
        return $s;
    });
    $command = rr_command_current();
} catch (Throwable $e) {
    rr_json(['ok'=>false, 'error'=>'storage_unavailable'], 503);
}
rr_json(['ok'=>true, 'device_id'=>$deviceId, 'server_time_ms'=>(int)floor(microtime(true)*1000), 'command_id'=>(string)($command['id'] ?? 'boot-stop'), 'action'=>(string)($command['action'] ?? 'STOP'), 'speed'=>(int)($command['speed'] ?? 0), 'expires_at_ms'=>(int)($command['expires_at_ms'] ?? 0), 'estop_latched'=>(bool)($command['estop_latched'] ?? false), 'server_state'=>(string)($command['server_state'] ?? 'idle')]);
