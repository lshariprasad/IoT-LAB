<?php
declare(strict_types=1);
require dirname(__DIR__) . '/_bootstrap.php';
rr_method('POST');
rr_require_device();
global $rr_config;
$data = rr_body_json(4096);
$deviceId = (string)($data['device_id'] ?? '');
if (!hash_equals((string)$rr_config['device_id'], $deviceId)) rr_json(['ok'=>false, 'error'=>'device_id_mismatch'], 403);
$allowedActions = ['FORWARD','REVERSE','LEFT','RIGHT','STOP','ESTOP','UNKNOWN'];
$action = strtoupper((string)($data['last_command'] ?? 'UNKNOWN'));
if (!in_array($action, $allowedActions, true)) $action = 'UNKNOWN';
$mode = (string)($data['control_mode'] ?? 'cloud');
if (!in_array($mode, ['cloud','stopped','unknown'], true)) $mode = 'unknown';
$ints = ['rssi'=>[-127,0], 'uptime_s'=>[0,2147483647], 'free_heap'=>[0,2147483647], 'left_pwm'=>[-255,255], 'right_pwm'=>[-255,255]];
$clean = [];
foreach ($ints as $key => [$min,$max]) {
    $v = $data[$key] ?? null;
    $clean[$key] = (is_int($v) || (is_string($v) && preg_match('/^-?\d{1,12}$/', $v))) ? max($min, min($max, (int)$v)) : null;
}
$fw = substr(preg_replace('/[^A-Za-z0-9._+-]/', '', (string)($data['firmware_version'] ?? '')), 0, 40);
$lastId = substr(preg_replace('/[^A-Za-z0-9_-]/', '', (string)($data['last_command_id'] ?? '')), 0, 64);
$result = substr(preg_replace('/[^A-Za-z0-9._ -]/', '', (string)($data['last_command_result'] ?? '')), 0, 60);
$now = time();
try {
    rr_update_json('status.json', [], function(array $s) use ($deviceId, $now, $clean, $fw, $lastId, $action, $mode, $result): array {
        $s['device_id'] = $deviceId;
        $s['last_seen_ts'] = $now;
        $s['last_seen_iso'] = gmdate('c', $now);
        $s['last_report_ts'] = $now;
        $s['last_report_iso'] = gmdate('c', $now);
        foreach ($clean as $k=>$v) $s[$k] = $v;
        $s['firmware_version'] = $fw !== '' ? $fw : null;
        $s['last_command_id'] = $lastId !== '' ? $lastId : null;
        $s['last_command'] = $action;
        $s['control_mode'] = $mode;
        $s['last_command_result'] = $result !== '' ? $result : null;
        return $s;
    });
} catch (Throwable $e) {
    rr_json(['ok'=>false, 'error'=>'storage_unavailable'], 503);
}
rr_json(['ok'=>true, 'ack'=>'report_received', 'received_at'=>gmdate('c', $now)]);
