# Hostinger + FileZilla deployment

## 0. Backup first

1. Sign in to Hostinger hPanel and open the website for `roborace.generai.in`.
2. Open the domain's file manager and identify the **actual document root** shown in the hosting panel. It is commonly a folder such as `domains/roborace.generai.in/public_html`, but verify it in hPanel rather than assuming.
3. Download a backup of the current site files before changing anything. If a website is already running, deploy to a staging subdirectory/subdomain first and merge deliberately.

## 1. Upload public website files

Use FileZilla or Hostinger File Manager. Upload the **contents of this package's `public_html/` folder** into the verified domain document root, preserving subfolders (`assets/`, `api/`, `device/`). Do not upload the package's outer folder as the public root unless the domain is explicitly configured to use it.

This package's `index.php` becomes the dashboard entry point. If existing `index.html` or another `index.php` is important, back it up and resolve the index priority before replacing anything.

## 2. Upload private configuration outside the web root

Upload `private/config.php` and the `private/storage/` directory as a sibling of the document root. Keep `private/DEPLOYMENT_SECRETS.txt` on your local computer only; do not upload it. Example server layout:

```text
/domain-account/
  private/
    config.php
    storage/
  public_html/     <-- actual document root
    index.php
    _bootstrap.php
    assets/
    api/
    device/
```

The dashboard's PHP looks for `../private/config.php` relative to the document root. If your Hostinger folder layout differs, adjust the path in `_bootstrap.php` to the correct **absolute server path**. Do not move `config.php` into a publicly served folder. If your plan prevents sibling-directory access, ask Hostinger support for the correct private path or deny-web-access configuration before proceeding.

`private/storage/` must be writable by the PHP process. Use the hosting account's normal restrictive permissions. Avoid `777`; ask Hostinger support for the correct owner/group if writes fail. The PHP code creates JSON files and lock files there.

## 3. Keep secrets private

- `private/config.php` contains a device API token and dashboard password hash.
- `private/DEPLOYMENT_SECRETS.txt` contains the initial dashboard password and API token. Keep it on your local computer and do not upload it to the server.
- The API token is also embedded in `firmware/ESP32_Dual_BTS7960_Hostinger_Cloud.ino`. This is necessary for the device to authenticate, but it means anyone with the source can extract it. Rotate it before public source sharing.
- Change the initial dashboard password before sharing the URL with anyone.
- Never put Wi-Fi credentials or API tokens in HTML, CSS, or browser-side JavaScript.

To change the dashboard password hash, run PHP on a trusted computer or server:

```bash
php -r "echo password_hash('YOUR_NEW_LONG_PASSWORD', PASSWORD_DEFAULT), PHP_EOL;"
```

Replace `dashboard_password_hash` in `private/config.php` with the generated hash. Do not place the plain password in `config.php`.

To rotate the API token, generate a 64-character hex token (for example `php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"`), update `device_token` in `private/config.php`, and update `DEVICE_TOKEN` in the ESP32 sketch before re-uploading the firmware.

## 4. HTTPS

Enable/verify SSL for `roborace.generai.in` in Hostinger hPanel before testing the API. `.htaccess` redirects HTTP to HTTPS. Verify the site loads with a valid certificate and no browser warning.

The included ESP32 sketch verifies TLS using the included ISRG Root X1 certificate. That works only if the site's current certificate chain is valid under that root. Verify the actual certificate chain for your domain. If it uses a different root CA, replace the PEM in `firmware/root_ca.h` with the appropriate trusted root certificate, then compile again. Do not replace certificate verification with `setInsecure()` for real motor control.

## 5. Verify server PHP before flashing firmware

Open:

- `https://roborace.generai.in/health.php` — should return JSON such as `{"ok":true,"service":"roborace-cloud","php":"8.x"}`.
- `https://roborace.generai.in/` — should show the login page.

Do not test device endpoints from the browser without the device token; a `401` response is expected without authentication. A dashboard login should open the control room. Status shows `UNKNOWN`/offline until a real ESP32 successfully polls the server.

If the `health.php` URL returns a download, 404, or PHP source, stop: PHP routing/document-root setup is not correct yet. Do not flash the firmware until the backend works.

## 6. Flash the ESP32 integration candidate

1. Open `firmware/ESP32_Dual_BTS7960_Hostinger_Cloud.ino` in Arduino IDE as a sketch folder with `root_ca.h` next to it.
2. Install the `ArduinoJson` library (v6 or v7) via Library Manager.
3. Choose the actual ESP32 board and COM port.
4. Verify Wi-Fi settings, `BASE_URL`, `DEVICE_ID`, `DEVICE_TOKEN`, pins and TLS root CA.
5. Keep the motor wheels raised and the physical battery disconnect accessible.
6. Upload the sketch and open Serial Monitor at 115200 baud.
7. Confirm Wi-Fi connection and successful HTTPS endpoint responses before enabling any movement test.

This firmware candidate uses the earlier dual-BTS7960 pin map. It is **not** the four-motor FlySky receiver + Cytron MDDS10 architecture described in the design README. Do not flash it to that robot without a deliberate architecture change and a review of actual source code.

## 7. Safe first test

1. Power the ESP32 and logic circuit with motor power disconnected if practical.
2. Confirm device appears ONLINE in the dashboard.
3. Test E-stop while wheels are raised, then clear it; the robot must remain stopped.
4. Start at the minimum slider value. Briefly press Forward and release; confirm the ESP32 report and actual PWM values change.
5. Verify release sends STOP, and closing the browser or losing cloud poll causes the server expiry/firmware timeout to stop the motors.
6. Disconnect Wi-Fi or block the endpoint during a wheel-raised test and confirm the firmware stops.
7. Do not use cloud commands for high-speed competition driving.

The cloud E-stop cannot physically disconnect motor power and cannot be treated as a safety-rated emergency stop.
