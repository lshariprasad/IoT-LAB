# Testing and Troubleshooting

## Expected operation

- Dashboard initially shows `UNKNOWN`/`Awaiting first heartbeat` until the ESP32 contacts `/device/poll.php` with the correct token and device ID.
- After polling, the device should become ONLINE within a few seconds.
- `health.php` should return JSON with `ok: true` if PHP is running.
- A dashboard movement command is first **accepted by the server**. It is not shown as executed until telemetry reports the corresponding `command_id` and output state.
- If the device stops reporting, the UI marks it offline after the configured timeout. Movement controls are disabled when offline.
- Movement commands expire on the server after about 1.3 seconds without browser renewal, and the firmware has a separate cloud-poll timeout of about 1.7 seconds.

## Server tests

### 1. PHP health check
Open `https://roborace.generai.in/health.php`. Expected JSON:

```json
{"ok":true,"service":"roborace-cloud","php":"8.x"}
```

### 2. Dashboard authentication
Open the root domain and sign in using the credentials stored in `private/DEPLOYMENT_SECRETS.txt`. Change these credentials before public sharing.

### 3. Authenticated status
After login, the browser calls `/api/status.php`. It should return JSON with `ok`, `device`, and `command`. Before the ESP32 first checks in, `device.online` is false and telemetry fields are null/unavailable.

### 4. Device authentication
A `401 device_authentication_failed` from a device endpoint usually means the `X-Device-Token` header does not match `private/config.php`. Do not expose the token in a browser request.

## Common errors

| Symptom | Likely cause | Action |
|---|---|---|
| `404 Not Found` | Files uploaded into wrong folder or missing `api/`/`device/` folders | Verify Hostinger's actual document root and upload the contents of `public_html/` with folders intact |
| `403` on login/logout | CSRF token mismatch, wrong session/cookie context, or `.htaccess` rule | Use HTTPS, reload the login page, ensure cookies are enabled, check error logs |
| `401` on device endpoint | Incorrect or missing `X-Device-Token`, or mismatched device ID | Compare `DEVICE_TOKEN`/`DEVICE_ID` in firmware with `private/config.php` |
| `500` / `storage_unavailable` | Private storage not writable or path wrong | Correct sibling private path and restrictive ownership/permissions; inspect Hostinger PHP error log privately |
| `503` setup incomplete | `_bootstrap.php` cannot find `../private/config.php` | Adjust config path to the real server layout and keep it outside document root |
| `invalid_json` | Body is not JSON or malformed | Confirm `Content-Type: application/json` and inspect request payload without sharing tokens |
| ESP32 TLS connection fails | Root CA doesn't match website certificate chain, clock not set, SSL not enabled, or network issue | Verify HTTPS certificate chain; update `root_ca.h` if needed; check DNS and serial errors. Do not use insecure TLS for a live robot |
| ESP32 stays offline | Wi-Fi credentials wrong, DNS unavailable, PHP endpoint error, token mismatch, or TLS failure | Inspect Serial Monitor at 115200 and verify `health.php`; check host server logs |
| Dashboard says accepted but not acknowledged | Server accepted command but robot has not polled/reported it, or command expired | Check `device_token`, `device_id`, firmware polling and report requests; do not treat acceptance as execution |
| Control buttons disabled | Device is offline or E-stop latched | Confirm heartbeat, then clear the latch while stopped; movement must still be explicitly commanded |
| Motors fail to move | Hardware/driver power issue, wrong board/pin map, wiring, disabled driver, or firmware error | Use the actual wiring diagram and current source; test only with wheels raised; do not assume a cloud code fix will solve electrical faults |
| Site redirects endlessly | HTTPS proxy setting conflicts with `.htaccess` rewrite | Ask Hostinger support to confirm HTTPS environment variable/reverse-proxy handling; temporarily back up and adjust redirect rules only after confirming SSL |

## Arduino Serial Monitor

Exact output varies with the Wi-Fi, PHP and TLS status. Typical successful messages include:

```text
RoboRace ESP32 Hostinger Cloud Integration
Boot safety: motor drivers disabled; outputs zero.
Verify the website TLS CA before testing cloud commands.
Connecting to Wi-Fi SSID: SSE-EEE
...
Command <id> | action=STOP | speed=0
```

If TLS validation fails, the HTTP poll will fail and the firmware should keep the motors stopped. Do not assume Wi-Fi connection alone means cloud connectivity works.

## Hardware validation not performed here

The package has not been flashed to the user's board or connected to motors. Before real movement, verify actual board variant, exact BTS7960 modules, supply/logic requirements, shared ground, motor polarity, current ratings, wheel clearance, fuse and physical disconnect. This cloud link has variable internet latency and is only intended for low-speed bench verification.
