# Protocol reference (for debugging)

All device requests use HTTPS and the header:

`X-Device-Token: <token configured privately and in firmware>`

## Device poll

`POST /device/poll.php`

```json
{"device_id":"roborace-esp32-01","last_command_id":"boot-stop"}
```

Successful response includes `command_id`, `action`, `speed`, `expires_at_ms`, `estop_latched`, and `server_state`.

## Device report

`POST /device/report.php`

```json
{
  "device_id":"roborace-esp32-01",
  "rssi":-52,
  "uptime_s":125,
  "free_heap":180000,
  "firmware_version":"rr-cloud-0.1.0",
  "control_mode":"cloud",
  "left_pwm":0,
  "right_pwm":0,
  "last_command_id":"boot-stop",
  "last_command":"STOP",
  "last_command_result":"startup_stopped"
}
```

Only values measured/reported by the firmware are recorded. No battery or external sensor telemetry is fabricated.

## Dashboard command

`POST /api/command.php` with authenticated session and `X-CSRF-Token`:

```json
{"action":"FORWARD","speed":80}
```

Allowed action names are `FORWARD`, `REVERSE`, `LEFT`, `RIGHT`, `STOP`, `ESTOP`, and `CLEAR_ESTOP`. Cloud PWM is capped by server config (150) and firmware constant (150). Movement commands expire unless the browser continues its hold-to-move renewal.
