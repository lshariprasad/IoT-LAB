/* FluidGuard static dashboard. The ESP32 remains responsible for local control. */
(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const DEFAULT_URL = 'http://192.168.43.124';
  const HISTORY_LIMIT = 30;

  let deviceUrl = (localStorage.getItem('fluidguard_device_url') || DEFAULT_URL).replace(/\/+$/, '');
  let username = localStorage.getItem('fluidguard_username') || 'admin';
  let password = sessionStorage.getItem('fluidguard_password') || 'ChangeMe-123!';
  let connected = false;
  let timer = null;
  let lastState = null;
  let lastAngle = null;
  let lastBuzzer = null;
  let lastWiFi = null;
  let events = [];

  $('deviceUrl').value = deviceUrl;
  $('username').value = username;
  $('password').value = password;

  function setConnection(ok, message) {
    connected = ok;
    const pill = $('connectionPill');
    pill.classList.toggle('connected', ok);
    pill.classList.toggle('error', !ok && message !== 'Not connected');
    $('connectionText').textContent = message;
    $('lastUpdated').textContent = ok ? 'Device responding live' : 'Waiting for device data';
  }

  function timeStamp() {
    return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  function logEvent(message, type = 'info') {
    events.unshift({ time: timeStamp(), message, type });
    events = events.slice(0, HISTORY_LIMIT);
    renderEvents();
  }

  function renderEvents() {
    const root = $('activityLog');
    if (!events.length) {
      root.innerHTML = '<div class="empty-log">No events yet. Connect to the ESP32.</div>';
      return;
    }
    root.innerHTML = events.map((item) =>
      `<div class="activity-item"><div class="activity-time">${escapeHtml(item.time)}</div><div class="activity-text">${escapeHtml(item.message)}</div></div>`
    ).join('');
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function normalizeBaseUrl(value) {
    const parsed = new URL(value.trim());
    if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Use an http:// or https:// ESP32 API URL.');
    return parsed.href.replace(/\/+$/, '');
  }

  function authHeader() {
    return 'Basic ' + btoa(unescape(encodeURIComponent(`${username}:${password}`)));
  }

  async function api(path, { timeoutMs = 5000 } = {}) {
    if (!deviceUrl) throw new Error('Enter the ESP32 URL first.');
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(deviceUrl + path, {
        method: 'GET',
        mode: 'cors',
        cache: 'no-store',
        headers: { 'Authorization': authHeader(), 'Accept': 'application/json, text/plain, */*' },
        signal: controller.signal,
        // Supported by newer Chromium browsers for local-device access prompts.
        targetAddressSpace: 'local'
      });
      const text = await response.text();
      if (!response.ok) throw new Error(`HTTP ${response.status}: ${text || response.statusText}`);
      return text;
    } finally {
      clearTimeout(timeout);
    }
  }

  async function fetchStatus() {
    const raw = await api('/api/status', { timeoutMs: 4500 });
    let data;
    try { data = JSON.parse(raw); } catch { throw new Error('ESP32 returned invalid status JSON. Upload the matching firmware from this package.'); }
    return data;
  }

  function updateBadge(el, text, kind) {
    el.textContent = text;
    el.className = `tag ${kind || 'tag-neutral'}`;
  }

  function renderStatus(s) {
    const validWeight = typeof s.weight_g === 'number' && Number.isFinite(s.weight_g);
    $('weightValue').textContent = validWeight ? s.weight_g.toFixed(1) : '—';
    $('weightBar').style.width = validWeight ? `${Math.max(0, Math.min(100, s.weight_g / 1000 * 100))}%` : '0%';
    $('weightHint').textContent = !validWeight ? 'A calibrated, healthy sensor is required.' : (s.weight_g <= 200 ? 'Weight is at or below the alert threshold.' : 'Weight is above the alert threshold.');

    const state = String(s.state || 'UNKNOWN');
    $('stateText').textContent = state;
    const stateBadge = $('stateBadge');
    stateBadge.className = 'state-badge ' + (state === 'NORMAL' ? 'state-good' : (s.alarm ? 'state-alert' : 'state-wait'));
    $('stateDescription').textContent = state === 'NORMAL'
      ? 'Weight is above 200 g. Automatic control commands 0° and buzzer OFF.'
      : (s.alarm ? 'Alert priority is active. Servo is commanded to 45° and the buzzer is ON.' : 'Check sensor readiness and calibration.');

    $('servoAngle').textContent = (s.servo_angle === 0 || s.servo_angle === 45) ? s.servo_angle : '—';
    $('servoState').textContent = s.servo_angle === 0 ? 'OFF · 0°' : (s.servo_angle === 45 ? 'ON · 45°' : 'Unknown');
    updateBadge($('buzzerBadge'), s.buzzer_on ? 'Sounding' : 'Off', s.buzzer_on ? 'tag-red' : 'tag-green');
    $('buzzerDetail').textContent = s.buzzer_on ? 'Alarm output active' : 'No buzzer output';
    $('sensorDetail').textContent = s.sensor_ok ? 'Reading successfully' : (s.scale_ready ? 'Waiting or read error' : 'Not detected');
    updateBadge($('sensorBadge'), s.sensor_ok ? 'Ready' : 'Check', s.sensor_ok ? 'tag-green' : 'tag-amber');
    updateBadge($('calibrationBadge'), s.calibrated ? 'Calibrated' : 'Required', s.calibrated ? 'tag-green' : 'tag-amber');
    updateBadge($('sensorReadyTag'), s.sensor_ok ? 'Ready' : 'Not ready', s.sensor_ok ? 'tag-green' : 'tag-amber');
    $('modeValue').textContent = s.auto_mode ? 'Automatic' : 'Manual';
    $('autoModeBtn').classList.toggle('active', !!s.auto_mode);
    $('manualModeBtn').classList.toggle('active', !s.auto_mode);
    $('modeHelp').textContent = s.auto_mode
      ? 'Automatic mode: at ≤ 200 g, servo is commanded to 45° and the buzzer sounds. Above 200 g, servo returns to 0° and buzzer turns off.'
      : 'Manual mode: Servo ON commands 45°; Servo OFF commands 0°. A low-weight or sensor-failure alert still takes priority.';
    $('servoOffBtn').disabled = !!s.alarm || !s.sensor_ok;
    $('servoOnBtn').disabled = !s.sensor_ok;

    const wifi = !!s.wifi_connected;
    $('ip').textContent = s.ip || 'Not connected';
    if (wifi !== lastWiFi) {
      logEvent(wifi ? `ESP32 connected to Wi-Fi. IP: ${s.ip}` : 'ESP32 Wi-Fi is offline; local monitoring continues.', wifi ? 'success' : 'warning');
      lastWiFi = wifi;
    }
    setConnection(true, wifi ? 'Device connected · Wi-Fi online' : 'Device reachable · Wi-Fi offline');
    $('lastUpdated').textContent = `Updated ${timeStamp()}`;

    if (lastState !== null && state !== lastState) logEvent(`System state changed to ${state}.`, s.alarm ? 'warning' : 'info');
    if (lastAngle !== null && s.servo_angle !== lastAngle) logEvent(`Servo commanded to ${s.servo_angle}°.`, 'info');
    if (lastBuzzer !== null && !!s.buzzer_on !== lastBuzzer) logEvent(`Buzzer ${s.buzzer_on ? 'ON' : 'OFF'}.`, s.buzzer_on ? 'warning' : 'info');
    lastState = state;
    lastAngle = s.servo_angle;
    lastBuzzer = !!s.buzzer_on;
  }

  async function refreshStatus() {
    try {
      const s = await fetchStatus();
      renderStatus(s);
    } catch (error) {
      setConnection(false, error.name === 'AbortError' ? 'Device timed out' : 'Device unreachable');
      $('stateText').textContent = 'Connection unavailable';
      $('stateBadge').className = 'state-badge state-wait';
      $('stateDescription').textContent = 'The ESP32 continues local control without the webpage. Check the IP, network, credentials, and browser local-network permission.';
      if (connected) logEvent(`Dashboard connection lost: ${error.message}`, 'warning');
      connected = false;
      $('commandMessage').textContent = 'Connect to the ESP32 to enable commands.';
    }
  }

  async function doCommand(path, label, target = 'commandMessage') {
    $(target).textContent = 'Sending command…';
    try {
      const text = await api(path);
      $(target).textContent = text;
      logEvent(text, 'info');
      await refreshStatus();
    } catch (error) {
      $(target).textContent = `Command failed: ${error.message}`;
      logEvent(`Command failed: ${error.message}`, 'warning');
    }
  }

  function connect() {
    try {
      deviceUrl = normalizeBaseUrl($('deviceUrl').value);
      username = $('username').value.trim();
      password = $('password').value;
      if (!username || !password) throw new Error('Enter the web username and password.');
      localStorage.setItem('fluidguard_device_url', deviceUrl);
      localStorage.setItem('fluidguard_username', username);
      sessionStorage.setItem('fluidguard_password', password);
      logEvent(`Connecting to ${deviceUrl}`, 'info');
      $('commandMessage').textContent = 'Trying the ESP32 API…';
      refreshStatus();
      if (timer) clearInterval(timer);
      timer = setInterval(refreshStatus, 1500);
    } catch (error) {
      $('commandMessage').textContent = error.message;
    }
  }

  $('connectBtn').addEventListener('click', connect);
  $('disconnectBtn').addEventListener('click', () => {
    if (timer) clearInterval(timer);
    timer = null;
    setConnection(false, 'Not connected');
    $('commandMessage').textContent = 'Dashboard disconnected. ESP32 local control remains active.';
    logEvent('Dashboard disconnected by user.', 'info');
  });
  $('servoOffBtn').addEventListener('click', () => doCommand('/servo?state=off', 'Servo OFF'));
  $('servoOnBtn').addEventListener('click', () => doCommand('/servo?state=on', 'Servo ON'));
  $('autoModeBtn').addEventListener('click', () => doCommand('/mode?mode=auto', 'Automatic mode'));
  $('manualModeBtn').addEventListener('click', () => doCommand('/mode?mode=manual', 'Manual mode'));
  $('tareBtn').addEventListener('click', () => {
    if (confirm('Remove all weight from the platform before tare. Continue?')) doCommand('/tare', 'Tare', 'calibrationMessage');
  });
  $('calibrateBtn').addEventListener('click', () => {
    const grams = Number($('knownMass').value);
    if (!Number.isFinite(grams) || grams < 50 || grams > 1000) {
      $('calibrationMessage').textContent = 'Enter a known reference mass from 50 to 1000 g.';
      return;
    }
    doCommand('/calibrate?grams=' + encodeURIComponent(grams), 'Calibration', 'calibrationMessage');
  });
  $('clearLogBtn').addEventListener('click', () => { events = []; renderEvents(); });

  setConnection(false, 'Not connected');
  logEvent('Dashboard loaded. Press Connect to reach the ESP32.', 'info');
})();
