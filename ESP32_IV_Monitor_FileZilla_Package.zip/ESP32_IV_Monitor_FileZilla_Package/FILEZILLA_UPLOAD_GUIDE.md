# FileZilla upload guide

## Upload the dashboard

1. Extract `ESP32_IV_Monitor_FileZilla_Package.zip` on your computer.
2. Open FileZilla and connect to your web-hosting FTP/SFTP details.
3. Navigate to your site's document root, commonly `public_html`, `htdocs`, or `www`.
4. Optionally create a directory named `fluidguard`.
5. From the local pane, open `web-dashboard`. Upload `index.html` and the complete `assets` folder.
6. Open the hosted page in a browser, e.g. `https://your-domain.example/fluidguard/`.
7. Get the ESP32's current IP from Arduino Serial Monitor (115200 baud). In the dashboard's connection card, enter an address such as `http://192.168.43.124`, username `admin`, and the current web password; click **Connect**.

Upload this structure, not the outer package folder:

```text
public_html/
└── fluidguard/
    ├── index.html
    └── assets/
        ├── app.js
        └── style.css
```

Do not upload `esp32-firmware/` to your public web root. Flash the `.ino` using Arduino IDE.

## Matching firmware is required

The dashboard calls these ESP32 endpoints:

- `GET /api/status`
- `GET /servo?state=on` and `GET /servo?state=off`
- `GET /mode?mode=auto` and `GET /mode?mode=manual`
- `GET /tare`
- `GET /calibrate?grams=500` (replace 500 with your known reference mass)

The matching `.ino` file in `esp32-firmware/` implements those endpoints and browser CORS preflight handling. Existing firmware without these CORS/API routes may not work from a separately hosted page.

## Network limitation

A FileZilla upload only publishes the frontend. It cannot make an ESP32's private IP reachable from anywhere on the internet. Direct control requires the browser to reach the ESP32, usually from the same Wi-Fi network. On HTTPS-hosted pages, your browser may ask for Local Network Access permission or block the request. Campus Wi-Fi client isolation can also block it. If you need access from outside the local network, use a secured VPN/tunnel or a cloud relay/backend; do not directly expose the ESP32 HTTP server to the public internet.
