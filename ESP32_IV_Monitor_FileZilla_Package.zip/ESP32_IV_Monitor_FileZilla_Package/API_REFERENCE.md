# Dashboard ↔ ESP32 API contract

All API routes use HTTP GET and HTTP Basic Authentication.

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/status` | Read weight, sensor readiness, calibration, servo command, buzzer, mode, Wi-Fi and system state |
| GET | `/servo?state=on` | Set manual servo ON (45°) |
| GET | `/servo?state=off` | Set manual servo OFF (0°), unless a low-weight/sensor alert is active |
| GET | `/mode?mode=auto` | Return to automatic weight control |
| GET | `/mode?mode=manual` | Enable manual servo controls |
| GET | `/tare` | Tare the empty platform; calibration factor is retained |
| GET | `/calibrate?grams=500` | Calibrate using a known 500 g reference load |

A successful `/api/status` response looks like:

```json
{
  "weight_g": 425.7,
  "scale_ready": true,
  "calibrated": true,
  "sensor_ok": true,
  "alarm": false,
  "buzzer_on": false,
  "servo_angle": 0,
  "auto_mode": true,
  "wifi_connected": true,
  "ip": "192.168.43.124",
  "state": "NORMAL"
}
```

The firmware includes CORS headers and OPTIONS handling to support a static frontend hosted on a different origin. A browser's local-network/mixed-content permissions and the network routing rules still apply.
