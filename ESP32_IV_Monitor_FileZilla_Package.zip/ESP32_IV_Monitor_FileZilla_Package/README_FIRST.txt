FLUIDGUARD ESP32 IV WEIGHT MONITOR - FILEZILLA PACKAGE
====================================================

CONTENTS
--------
web-dashboard/
  index.html          Dashboard page
  assets/style.css    Responsive dashboard design
  assets/app.js       Live API connection, controls, calibration, event log

esp32-firmware/
  ESP32_IV_Monitor_CORS.ino
                      Matching ESP32 firmware with CORS support for the
                      separately hosted dashboard, LCD-first local display,
                      offline weight control, saved HX711 calibration, and
                      local servo/buzzer control.

FILEZILLA: WHAT TO UPLOAD
-------------------------
1. Extract this ZIP on your computer.
2. Connect to your normal web-hosting account using FileZilla.
3. Open the web root folder (often public_html, htdocs, or www).
4. Create a folder such as fluidguard if desired.
5. Upload ONLY the CONTENTS of the web-dashboard folder into that folder.
   The web root should contain:
       index.html
       assets/style.css
       assets/app.js
6. Do NOT upload the esp32-firmware folder to a public web root. Keep the
   firmware source on your computer and upload it to the ESP32 using Arduino IDE.
7. Open the website URL in a browser.
8. In the dashboard's "Connect to ESP32" card, enter the current IP printed
   in Serial Monitor, such as http://192.168.43.124. The exact IP can change.
9. Use the configured website credentials (defaults shown below) and press Connect.

DEFAULT SETTINGS - CHANGE BEFORE DEPLOYMENT
-------------------------------------------
Wi-Fi SSID:       SSE-EEE
Wi-Fi password:   123456789
Dashboard login:  admin
Dashboard password: ChangeMe-123!
Servo OFF:        0 degrees
Servo ON:         45 degrees
Low-weight alert: at or below 200 g

The firmware source has the Wi-Fi password and default HTTP basic-auth password
embedded because it is an editable educational prototype. Change the web
password in BOTH the firmware and dashboard connection form before use on a
shared network. Do not publish the firmware source ZIP publicly with real
credentials in it.

IMPORTANT: FILEZILLA DOES NOT CREATE INTERNET CONNECTIVITY TO THE ESP32
-----------------------------------------------------------------------
FileZilla only transfers files to a hosting server. The ESP32 in the current
setup has a private/local IP address. The hosted website can control the ESP32
only when the visitor's browser can reach that ESP32 IP and the network permits
local-device access.

For local testing:
- Computer/phone and ESP32 must be connected to the same Wi-Fi network.
- Use the current ESP32 IP from Serial Monitor, not an assumed old IP.
- If Chrome asks permission to access a local device/network, allow it for your
  dashboard site if you trust that site.
- Campus Wi-Fi may isolate clients. If so, the browser cannot reach the ESP32
  directly even if the ESP32 has an IP address.

If the hosted website is HTTPS but the ESP32 API is plain HTTP, modern browsers
may block direct requests or require Local Network Access permission. The JS
requests declare the target as a local address where supported, and the firmware
provides CORS/preflight headers, but browser and network policy still apply.

For access from outside the same local network, a private IP like 192.168.x.x
is not routable across the public internet. You need a properly secured HTTPS
VPN/tunnel or a cloud relay and a corresponding backend. Do not expose the ESP32
HTTP API directly to the public internet or port-forward port 80 without a
security design.

OFFLINE FUNCTIONALITY
---------------------
The ESP32 firmware makes the weight/servo/buzzer/LCD decisions locally; it does
not require the website or Wi-Fi for those decisions. The LCD alternates between
weight/status and Wi-Fi status. Calibration is saved on ESP32 non-volatile
storage. A first-time or erased board must be calibrated once with a known mass.

SAFETY
------
Educational prototype only. Test using a nonmedical test load/container. This
is not a medical-grade infusion controller; servo commands do not confirm that
tubing is physically closed and cannot be used as a patient-safety guarantee.
