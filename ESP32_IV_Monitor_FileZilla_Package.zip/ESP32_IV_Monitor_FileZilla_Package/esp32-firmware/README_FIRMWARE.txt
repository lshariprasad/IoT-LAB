ESP32 IV Monitor firmware
=========================

Board: ESP32 Dev Module
Libraries to install in Arduino IDE Library Manager:
- HX711 by bogde
- ESP32Servo
- LiquidCrystal_I2C

Built-in ESP32 libraries used:
- WiFi.h
- WebServer.h
- Preferences.h
- Wire.h

Pins:
Servo signal      GPIO 27
HX711 DT          GPIO 4
HX711 SCK         GPIO 19
LCD SDA           GPIO 21
LCD SCL           GPIO 22
Active buzzer     GPIO 23

Rules:
- At/below 200 g: 45-degree servo command and buzzer ON.
- Above 200 g: 0-degree servo command and buzzer OFF in automatic mode.
- Website manual ON commands 45 degrees; manual OFF commands 0 degrees.
- Low weight/sensor failure has priority over manual OFF.
- LCD/weight/servo/buzzer logic is local and does not depend on Wi-Fi.
- The LCD alternates between current weight/state and Wi-Fi status.
- The device connects only to SSE-EEE and does not create a fallback AP.
- The calibration factor is stored in ESP32 Preferences after calibration.

IMPORTANT: Keep the HX711 platform unloaded during startup tare. Calibrate using
an accurate known mass (e.g. 500 g) with the mass sitting on the platform.
If calibration has been erased or is absent, the 200 g threshold is disabled
until you calibrate the scale from the website.

Servo external power supply must match the servo's rating. Tie external supply
GND to ESP32 GND. Do not power the servo from the 3V3 pin.

CORS NOTE: This sketch sends Access-Control-Allow-Origin: * and allows browser
Authorization headers so a separate static dashboard can call the API. Do not
expose this HTTP API directly to the public internet. Use only on a trusted local
network or behind a properly secured HTTPS VPN/tunnel/backend. Change the sample
web password before deployment.

Educational prototype only, not for patient use.
