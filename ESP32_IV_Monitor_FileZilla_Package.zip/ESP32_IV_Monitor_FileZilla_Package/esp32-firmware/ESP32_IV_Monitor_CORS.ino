#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <HX711.h>
#include <ESP32Servo.h>
#include <Preferences.h>
#include <math.h>
#include <string.h>

// ============================================================
// WIFI: ONLY SSE-EEE. There is NO fallback access point.
// ============================================================
const char* WIFI_SSID = "SSE-EEE";
const char* WIFI_PASSWORD = "123456789";

// Change both values before deployment on a shared network.
const char* WEB_USER = "admin";
const char* WEB_PASSWORD = "ChangeMe-123!";

// ============================================================
// GPIO PINS
// ============================================================
#define SERVO_PIN       27
#define HX711_DOUT       4
#define HX711_SCK       19
#define BUZZER_PIN      23
#define LCD_SDA         21
#define LCD_SCL         22
#define LCD_ADDRESS     0x27

// ============================================================
// APPLICATION SETTINGS
// ============================================================
const float LOW_WEIGHT_G = 200.0f;
const int SERVO_OFF_ANGLE = 0;
const int SERVO_ON_ANGLE = 45;

const unsigned long WIFI_INITIAL_WAIT_MS = 5000;
const unsigned long WIFI_RETRY_MS = 15000;
const unsigned long WEIGHT_INTERVAL_MS = 400;
const unsigned long SENSOR_TIMEOUT_MS = 3000;
const unsigned long LCD_REFRESH_MS = 300;
const unsigned long LCD_PAGE_INTERVAL_MS = 2500;

LiquidCrystal_I2C lcd(LCD_ADDRESS, 16, 2);
HX711 scale;
Servo myServo;
WebServer server(80);
Preferences preferences;

// Device state
bool scaleInitialized = false;
bool scaleCalibrated = false;
bool haveWeightReading = false;
bool autoMode = true;
bool manualServoOn = false;
bool alarmActive = false;
bool buzzerOn = false;
bool wifiWasConnected = false;
bool wifiFailureReported = false;
bool lcdShowWifiPage = false;

float calibrationFactor = 0.0f;
float weightGrams = 0.0f;
int servoAngle = -1;
String systemState = "WAITING FOR HX711";

unsigned long wifiStartMs = 0;
unsigned long lastWiFiRetryMs = 0;
unsigned long lastGoodReadMs = 0;
unsigned long lastWeightReadMs = 0;
unsigned long lastLCDRefreshMs = 0;
unsigned long lastLCDPageMs = 0;

// ============================================================
// CORS FOR A SEPARATELY HOSTED STATIC WEBSITE
// The website uses Basic Authorization and GET requests.
// Avoid exposing this HTTP API directly to the public internet.
// ============================================================
void addCorsHeaders() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
  server.sendHeader("Access-Control-Max-Age", "600");
  server.sendHeader("Access-Control-Allow-Private-Network", "true");
  server.sendHeader("Cache-Control", "no-store");
}

void handleOptions() {
  addCorsHeaders();
  server.send(204, "text/plain", "");
}

void sendCors(int code, const char* contentType, const String& body) {
  addCorsHeaders();
  server.send(code, contentType, body);
}

bool requireAuth() {
  if (server.authenticate(WEB_USER, WEB_PASSWORD)) {
    return true;
  }
  addCorsHeaders();
  server.requestAuthentication(BASIC_AUTH, "ESP32 Fluid Monitor");
  return false;
}

// ============================================================
// LCD: SHOW WEIGHT/STATE AND ALTERNATE WIFI STATUS
// ============================================================
void lcdLine(int row, const char* message) {
  lcd.setCursor(0, row);
  lcd.print(message);
  int n = strlen(message);
  while (n < 16) {
    lcd.print(' ');
    n++;
  }
}

bool sensorHealthy() {
  return scaleInitialized && haveWeightReading &&
         (millis() - lastGoodReadMs < SENSOR_TIMEOUT_MS);
}

bool lowWeightDetected() {
  return scaleCalibrated && sensorHealthy() &&
         (weightGrams <= LOW_WEIGHT_G);
}

bool sensorHasFailed() {
  return scaleInitialized && haveWeightReading &&
         (millis() - lastGoodReadMs >= SENSOR_TIMEOUT_MS);
}

void updateLCD() {
  unsigned long now = millis();
  if (now - lastLCDPageMs >= LCD_PAGE_INTERVAL_MS) {
    lastLCDPageMs = now;
    lcdShowWifiPage = !lcdShowWifiPage;
  }

  if (!scaleInitialized) {
    lcdLine(0, "HX711 WAITING");
  } else if (sensorHasFailed()) {
    lcdLine(0, "HX711 SENSOR ERR");
  } else if (!scaleCalibrated) {
    lcdLine(0, "CALIBRATE SCALE");
  } else if (haveWeightReading) {
    char line[17];
    snprintf(line, sizeof(line), "Weight:%7.1fg", weightGrams);
    lcdLine(0, line);
  } else {
    lcdLine(0, "WAITING WEIGHT");
  }

  if (lcdShowWifiPage) {
    lcdLine(1, WiFi.status() == WL_CONNECTED ? "WiFi:CONNECTED" : "WiFi:OFFLINE");
  } else if (systemState == "LOW WEIGHT ALERT") {
    lcdLine(1, "LOW S:45 B:ON");
  } else if (systemState == "SENSOR ERROR") {
    lcdLine(1, "ERROR S:45 B:ON");
  } else if (systemState == "MANUAL SERVO ON") {
    lcdLine(1, "MANUAL S:45 B:ON");
  } else if (systemState == "MANUAL SERVO OFF") {
    lcdLine(1, "MANUAL S:0 B:OFF");
  } else if (systemState == "NORMAL") {
    lcdLine(1, "NORMAL S:0 B:OFF");
  } else if (systemState == "CALIBRATE SCALE") {
    lcdLine(1, "CAL REQUIRED");
  } else {
    lcdLine(1, "WAITING HX711");
  }
}

// ============================================================
// HARDWARE OUTPUTS
// ============================================================
void setServoPosition(int angle) {
  if (angle != SERVO_OFF_ANGLE && angle != SERVO_ON_ANGLE) return;
  if (servoAngle != angle) {
    servoAngle = angle;
    myServo.write(angle);
    Serial.print("Servo commanded: ");
    Serial.print(angle);
    Serial.println(" degrees");
  }
}

void setBuzzer(bool enabled) {
  buzzerOn = enabled;
  digitalWrite(BUZZER_PIN, enabled ? HIGH : LOW);
}

// ============================================================
// CENTRAL CONTROL: LOCAL/OFFLINE OPERATION
// AUTO: <=200 g => 45 degrees + active buzzer ON
//       > 200 g => 0 degrees + buzzer OFF
// Manual website commands are overridden by low-weight/error.
// ============================================================
void updateControl() {
  if (sensorHasFailed()) {
    systemState = "SENSOR ERROR";
    alarmActive = true;
    setServoPosition(SERVO_ON_ANGLE);
    setBuzzer(true);
    return;
  }

  if (lowWeightDetected()) {
    systemState = "LOW WEIGHT ALERT";
    alarmActive = true;
    setServoPosition(SERVO_ON_ANGLE);
    setBuzzer(true);
    return;
  }

  alarmActive = false;

  if (!autoMode) {
    if (manualServoOn) {
      systemState = "MANUAL SERVO ON";
      setServoPosition(SERVO_ON_ANGLE);
      setBuzzer(true);
    } else {
      systemState = "MANUAL SERVO OFF";
      setServoPosition(SERVO_OFF_ANGLE);
      setBuzzer(false);
    }
    return;
  }

  if (!scaleInitialized) {
    systemState = "WAITING FOR HX711";
    setServoPosition(SERVO_OFF_ANGLE);
    setBuzzer(false);
    return;
  }

  if (!scaleCalibrated) {
    systemState = "CALIBRATE SCALE";
    setServoPosition(SERVO_OFF_ANGLE);
    setBuzzer(false);
    return;
  }

  if (!sensorHealthy()) {
    systemState = "WAITING FOR WEIGHT";
    setServoPosition(SERVO_OFF_ANGLE);
    setBuzzer(false);
    return;
  }

  systemState = "NORMAL";
  setServoPosition(SERVO_OFF_ANGLE);
  setBuzzer(false);
}

// ============================================================
// HX711 STARTUP / RECONNECT
// The load cell platform must be empty when tare runs.
// ============================================================
void initializeScaleIfReady() {
  if (scaleInitialized || !scale.is_ready()) return;

  Serial.println("HX711 detected. Initializing and taring...");
  scale.set_scale(1.0f);
  scale.tare(15);
  scaleInitialized = true;

  if (scaleCalibrated && isfinite(calibrationFactor) &&
      fabsf(calibrationFactor) > 0.000001f) {
    scale.set_scale(calibrationFactor);
    Serial.println("Saved calibration factor loaded.");
  } else {
    scaleCalibrated = false;
    scale.set_scale(1.0f);
    Serial.println("Scale needs calibration.");
  }

  lastGoodReadMs = millis();
  lastWeightReadMs = 0;
  Serial.println("HX711 initialized.");
}

// ============================================================
// API: CALIBRATION
// Calibrate with a known mass after taring an empty platform.
// ============================================================
void handleCalibration() {
  if (!requireAuth()) return;
  if (!scaleInitialized || !scale.is_ready()) {
    sendCors(409, "text/plain", "HX711 is not ready.");
    return;
  }
  if (!server.hasArg("grams")) {
    sendCors(400, "text/plain", "Enter a known mass in grams.");
    return;
  }

  float knownGrams = server.arg("grams").toFloat();
  if (!isfinite(knownGrams) || knownGrams < 50.0f || knownGrams > 1000.0f) {
    sendCors(400, "text/plain", "Use a known mass from 50 to 1000 grams.");
    return;
  }

  long rawDelta = scale.get_value(10);
  if (fabs((double)rawDelta) < 1000.0) {
    sendCors(409, "text/plain", "Reading too small. Check the load cell and known mass.");
    return;
  }

  float newFactor = (float)rawDelta / knownGrams;
  if (!isfinite(newFactor) || fabsf(newFactor) < 0.000001f) {
    sendCors(500, "text/plain", "Unable to calculate calibration factor.");
    return;
  }

  calibrationFactor = newFactor;
  scale.set_scale(calibrationFactor);
  scaleCalibrated = true;
  preferences.putFloat("calFactor", calibrationFactor);

  float measured = scale.get_units(5);
  if (!isfinite(measured)) {
    sendCors(500, "text/plain", "Invalid weight after calibration.");
    return;
  }

  weightGrams = (measured < 0.0f) ? 0.0f : measured;
  haveWeightReading = true;
  lastGoodReadMs = millis();
  updateControl();

  Serial.print("Calibration saved. Factor = ");
  Serial.println(calibrationFactor, 6);
  String response = "Calibration saved. Weight = ";
  response += String(weightGrams, 1);
  response += " g";
  sendCors(200, "text/plain", response);
}

// ============================================================
// API: TARE (REMOVE WEIGHT FIRST)
// ============================================================
void handleTare() {
  if (!requireAuth()) return;
  if (!scaleInitialized || !scale.is_ready()) {
    sendCors(409, "text/plain", "HX711 is not ready.");
    return;
  }

  scale.tare(15);
  weightGrams = 0.0f;
  haveWeightReading = false;
  lastGoodReadMs = millis();
  lastWeightReadMs = 0;
  updateControl();

  Serial.println("Tare completed. Calibration retained.");
  sendCors(200, "text/plain", "Tare complete. Calibration factor retained.");
}

// ============================================================
// API: SERVO ON/OFF
// ON=45 degrees; OFF=0 degrees. Low-weight/error takes priority.
// ============================================================
void handleServo() {
  if (!requireAuth()) return;
  if (!server.hasArg("state")) {
    sendCors(400, "text/plain", "Use state=on or state=off.");
    return;
  }

  String state = server.arg("state");
  state.toLowerCase();
  if (state != "on" && state != "off") {
    sendCors(400, "text/plain", "Only on and off are permitted.");
    return;
  }

  if (state == "off" && (lowWeightDetected() || sensorHasFailed())) {
    updateControl();
    sendCors(409, "text/plain", "OFF blocked: alert condition has priority.");
    return;
  }

  autoMode = false;
  manualServoOn = (state == "on");
  updateControl();

  sendCors(200, "text/plain", manualServoOn
      ? "Servo ON: commanded to 45 degrees."
      : "Servo OFF: commanded to 0 degrees.");
}

// ============================================================
// API: AUTOMATIC / MANUAL MODE
// ============================================================
void handleMode() {
  if (!requireAuth()) return;
  if (!server.hasArg("mode")) {
    sendCors(400, "text/plain", "Use mode=auto or mode=manual.");
    return;
  }

  String mode = server.arg("mode");
  mode.toLowerCase();
  if (mode == "auto") {
    autoMode = true;
    updateControl();
    sendCors(200, "text/plain", "Automatic weight control enabled.");
  } else if (mode == "manual") {
    autoMode = false;
    updateControl();
    sendCors(200, "text/plain", "Manual control enabled.");
  } else {
    sendCors(400, "text/plain", "Unknown mode.");
  }
}

// ============================================================
// API: DEVICE STATUS
// ============================================================
void handleStatus() {
  if (!requireAuth()) return;
  updateControl();
  bool connected = (WiFi.status() == WL_CONNECTED);

  String json;
  json.reserve(350);
  json = "{\"weight_g\":";
  if (scaleCalibrated && sensorHealthy()) json += String(weightGrams, 1);
  else json += "null";

  json += ",\"scale_ready\":"; json += scaleInitialized ? "true" : "false";
  json += ",\"calibrated\":"; json += scaleCalibrated ? "true" : "false";
  json += ",\"sensor_ok\":"; json += sensorHealthy() ? "true" : "false";
  json += ",\"alarm\":"; json += alarmActive ? "true" : "false";
  json += ",\"buzzer_on\":"; json += buzzerOn ? "true" : "false";
  json += ",\"servo_angle\":"; json += String(servoAngle);
  json += ",\"auto_mode\":"; json += autoMode ? "true" : "false";
  json += ",\"wifi_connected\":"; json += connected ? "true" : "false";
  json += ",\"ip\":\"";
  json += connected ? WiFi.localIP().toString() : String("Not connected");
  json += "\",\"state\":\""; json += systemState; json += "\"}";

  sendCors(200, "application/json", json);
}

// ============================================================
// ROUTES / SIMPLE API ROOT
// ============================================================
void setupWebServer() {
  server.on("/", HTTP_GET, []() {
    addCorsHeaders();
    server.send(200, "text/plain",
      "ESP32 Fluid Monitor API is running. Deploy the web-dashboard folder to your website.");
  });

  server.on("/api/status", HTTP_GET, handleStatus);
  server.on("/api/status", HTTP_OPTIONS, handleOptions);
  server.on("/calibrate", HTTP_GET, handleCalibration);
  server.on("/calibrate", HTTP_OPTIONS, handleOptions);
  server.on("/tare", HTTP_GET, handleTare);
  server.on("/tare", HTTP_OPTIONS, handleOptions);
  server.on("/servo", HTTP_GET, handleServo);
  server.on("/servo", HTTP_OPTIONS, handleOptions);
  server.on("/mode", HTTP_GET, handleMode);
  server.on("/mode", HTTP_OPTIONS, handleOptions);

  server.onNotFound([]() {
    if (server.method() == HTTP_OPTIONS) {
      handleOptions();
      return;
    }
    if (!requireAuth()) return;
    sendCors(404, "text/plain", "Endpoint not found.");
  });

  server.begin();
  Serial.println("Web server started.");
}

// ============================================================
// WIFI: 5 SECOND INITIAL WINDOW, THEN RETRY IN BACKGROUND
// ============================================================
void startWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  wifiStartMs = millis();
  lastWiFiRetryMs = millis();
  Serial.println("Connecting to SSE-EEE for up to 5 seconds...");
}

void serviceWiFi() {
  unsigned long now = millis();
  bool connected = (WiFi.status() == WL_CONNECTED);

  if (connected && !wifiWasConnected) {
    wifiWasConnected = true;
    wifiFailureReported = false;
    Serial.println("Wi-Fi connected.");
    Serial.print("Website/API IP: http://");
    Serial.println(WiFi.localIP());
  }

  if (!connected && wifiWasConnected) {
    wifiWasConnected = false;
    Serial.println("Wi-Fi disconnected. Local monitoring continues.");
    if (!autoMode) {
      autoMode = true;
      Serial.println("Returned to automatic control after Wi-Fi loss.");
    }
  }

  if (!connected && !wifiFailureReported &&
      now - wifiStartMs >= WIFI_INITIAL_WAIT_MS) {
    wifiFailureReported = true;
    Serial.println("Wi-Fi not connected after 5 seconds.");
    Serial.print("Wi-Fi name: "); Serial.println(WIFI_SSID);
    Serial.print("Wi-Fi password: "); Serial.println(WIFI_PASSWORD);
    Serial.println("No fallback network. Local control remains active.");
  }

  if (!connected && WiFi.status() == WL_DISCONNECTED &&
      now - lastWiFiRetryMs >= WIFI_RETRY_MS) {
    lastWiFiRetryMs = now;
    Serial.println("Retrying SSE-EEE...");
    WiFi.reconnect();
  }
}

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  delay(150);

  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  Wire.begin(LCD_SDA, LCD_SCL);
  lcd.init();
  lcd.backlight();
  lcdLine(0, "Fluid Monitor");
  lcdLine(1, "Starting local");

  myServo.setPeriodHertz(50);
  myServo.attach(SERVO_PIN, 500, 2400);
  setServoPosition(SERVO_OFF_ANGLE);

  preferences.begin("ivmonitor", false);
  if (preferences.isKey("calFactor")) {
    calibrationFactor = preferences.getFloat("calFactor", 0.0f);
    scaleCalibrated = isfinite(calibrationFactor) &&
                      fabsf(calibrationFactor) > 0.000001f;
  }

  scale.begin(HX711_DOUT, HX711_SCK);
  scale.set_scale(1.0f);
  initializeScaleIfReady();

  // Network startup is non-blocking; all hardware control is local.
  startWiFi();
  setupWebServer();

  updateControl();
  updateLCD();

  Serial.println("========================================");
  Serial.println("ESP32 FLUID MONITOR READY");
  Serial.println("Threshold: 200 g");
  Serial.println("Normal: servo 0 degrees, buzzer OFF");
  Serial.println("Alert: servo 45 degrees, buzzer ON");
  Serial.println("Offline-first sensor/servo/LCD logic enabled");
  Serial.println("Web user: admin");
  Serial.println("Web password: ChangeMe-123!");
  Serial.println("========================================");
}

// ============================================================
// MAIN LOOP: NEVER DEPEND ON WIFI FOR WEIGHT CONTROL
// ============================================================
void loop() {
  server.handleClient();
  serviceWiFi();
  initializeScaleIfReady();

  unsigned long now = millis();

  if (scaleInitialized && scaleCalibrated &&
      now - lastWeightReadMs >= WEIGHT_INTERVAL_MS) {
    lastWeightReadMs = now;

    if (scale.is_ready()) {
      float measured = scale.get_units(3);
      if (isfinite(measured)) {
        weightGrams = measured < 0.0f ? 0.0f : measured;
        haveWeightReading = true;
        lastGoodReadMs = millis();
      }
    }
  }

  updateControl();

  if (now - lastLCDRefreshMs >= LCD_REFRESH_MS) {
    lastLCDRefreshMs = now;
    updateLCD();
  }

  server.handleClient();
  delay(2);
}
